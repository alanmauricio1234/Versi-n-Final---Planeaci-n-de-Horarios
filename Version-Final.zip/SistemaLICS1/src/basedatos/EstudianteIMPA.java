package basedatos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import control.Historial;
import control.Registro;
import modelo.Cuenta;
import modelo.Estudiante;
import modelo.Historiales;

import java.sql.Connection;

public class EstudianteIMPA implements EstudianteIMP{
	private AdminBD admin;
	private Connection conexion;
	private boolean conexionTransferida;
	
	public EstudianteIMPA() {
		admin = new AdminBD();		
		conexion=null;
	}
	
	public EstudianteIMPA(Connection conexion) {
		this.conexion=conexion;
		conexionTransferida=true;
	}
	
	public int insertar(Estudiante estudiante) {
		int verificar=0;
		PreparedStatement ps=null;

		String sql="INSERT INTO estudiantes(matricula,nombre,apellidop,correo_institucional,apellidom,correo_personal,numero_casa,numero_celular) VALUES(?,?,?,?,?,?,?,?);";
		if(conexionTransferida==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);

			ps.setString(1, estudiante.getMatricula());
			ps.setString(2, estudiante.getNombre());
			ps.setString(3, estudiante.getApellidoP());
			ps.setString(4, estudiante.getCorreoInstitucional());
			ps.setString(5, estudiante.getApellidoM());
			ps.setString(6, estudiante.getCorreoPersonal());
			ps.setString(7, estudiante.getNumCasa());
			ps.setString(8, estudiante.getNumCelular());
			
			try{
				verificar=ps.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Los datos ya estan registrados");
			
			}finally {
				ps.close();
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				if(conexionTransferida==false)
					conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return verificar;
	}
	
	public int modificarEstudiante(Estudiante estudiante, String aux,int check) {
		int verificar=0;
		PreparedStatement ps=null;

		if( check == 1 ) {
		String sql="UPDATE estudiantes" + 
				" SET matricula=?,nombre=?,apellidop=?,correo_institucional=?,apellidom=?,correo_personal=?,numero_casa=?,numero_celular=?" + 
				" WHERE numero_casa=? AND correo_institucional=?;";
		if(conexionTransferida==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);

			ps.setString(1, estudiante.getMatricula());
			ps.setString(2, estudiante.getNombre());
			ps.setString(3, estudiante.getApellidoP());
			ps.setString(4, estudiante.getCorreoInstitucional());
			ps.setString(5, estudiante.getApellidoM());
			ps.setString(6, estudiante.getCorreoPersonal());
			ps.setString(7, aux);
			ps.setString(8, estudiante.getNumCelular());
			ps.setString(9, estudiante.getNumCasa());
			ps.setString(10, estudiante.getCorreoInstitucional());
			
			try{
				verificar=ps.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Los datos no se pudieron modiicar");
			
			}finally {
				ps.close();
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				if(conexionTransferida==false)
					conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		}
		if( check == 2 ) {
			String sql="UPDATE estudiantes" + 
					" SET matricula=?,nombre=?,apellidop=?,correo_institucional=?,apellidom=?,correo_personal=?,numero_casa=?,numero_celular=?" + 
					" WHERE numero_celular=? AND correo_institucional=?;";
			if(conexionTransferida==false)
				conexion=admin.dameConexion();
			
			try {
				ps=conexion.prepareStatement(sql);

				ps.setString(1, estudiante.getMatricula());
				ps.setString(2, estudiante.getNombre());
				ps.setString(3, estudiante.getApellidoP());
				ps.setString(4, estudiante.getCorreoInstitucional());
				ps.setString(5, estudiante.getApellidoM());
				ps.setString(6, estudiante.getCorreoPersonal());
				ps.setString(7, estudiante.getNumCasa());
				ps.setString(8, aux);
				ps.setString(9, estudiante.getNumCelular());
				ps.setString(10, estudiante.getCorreoInstitucional());
				
				try{
					verificar=ps.executeUpdate();
				}catch(SQLException e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "Los datos no se pudieron modiicar");
				
				}finally {
					ps.close();
				}
		
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					ps.close();
					if(conexionTransferida==false)
						conexion.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			}
		if( check == 3 ) {
			String sql="UPDATE estudiantes" + 
					" SET matricula=?,nombre=?,apellidop=?,correo_institucional=?,apellidom=?,correo_personal=?,numero_casa=?,numero_celular=?" + 
					" WHERE correo_personal=? AND correo_institucional=?;";
			if(conexionTransferida==false)
				conexion=admin.dameConexion();
			
			try {
				ps=conexion.prepareStatement(sql);

				ps.setString(1, estudiante.getMatricula());
				ps.setString(2, estudiante.getNombre());
				ps.setString(3, estudiante.getApellidoP());
				ps.setString(4, estudiante.getCorreoInstitucional());
				ps.setString(5, estudiante.getApellidoM());
				ps.setString(6, aux);
				ps.setString(7, estudiante.getNumCasa());
				ps.setString(8, estudiante.getNumCelular());
				ps.setString(9, estudiante.getCorreoPersonal());
				ps.setString(10, estudiante.getCorreoInstitucional());
				
				try{
					verificar=ps.executeUpdate();
				}catch(SQLException e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "Los datos no se pudieron modiicar");
				
				}finally {
					ps.close();
				}
		
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					ps.close();
					if(conexionTransferida==false)
						conexion.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			}
		return verificar;
	}
	
	public int contarCursando(Estudiante estudiante) {
		int conteos = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = "SELECT count(status) as status FROM historiales WHERE matricula=? AND status='cursando';";
		if(conexionTransferida==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);
			ps.setString(1, estudiante.getMatricula());
			
			try{
				rs = ps.executeQuery();
				if(rs.next())
				conteos = Integer.parseInt(rs.getString("status"));
				
				System.out.println(""+conteos);
			}catch(SQLException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Llave duplicada o error en el query");
			
			}
			ps.close();
			rs.close();
			admin.cerrarConexion(conexion);
		}catch(SQLException e) {
			  try {
				ps.close();
				  rs.close();
			      admin.cerrarConexion(conexion);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return conteos;
	}
	
	public int insertarHistorial(Historiales historial) {
		int verificar=0;
		PreparedStatement ps=null;

		String sql="INSERT INTO historiales(tipo_semestre,matricula,cve_materia,status) VALUES(?,?,?,?);";
		if(conexionTransferida==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);

			ps.setString(1, historial.getSemestre());
			ps.setString(2, historial.getMatricula());
			ps.setString(3, historial.getCve_materia());
			ps.setString(4, historial.getStatus());
	
			try{
				verificar=ps.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "La Materia ya fue registrada");
			
			}finally {
				ps.close();
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				if(conexionTransferida==false)
					conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return verificar;
	}
	
	public Cuenta consultar(Cuenta cuenta) {
		PreparedStatement ps=null;
		ResultSet rs=null;
		Cuenta cuentaHallada= null;
		String usuario,password,matricula;
		
 		String sql="SELECT correo_institucional,password,matricula FROM usuarioestudiante WHERE correo_institucional=? AND password=?;";

		try {
			conexion=admin.dameConexion();
			ps=conexion.prepareStatement(sql);
			ps.setString(1, cuenta.getCorreoInstitucional());
			ps.setString(2, cuenta.getPassword());
			rs=ps.executeQuery();

			while(rs.next()) {
				usuario=rs.getString("correo_institucional");
				password=rs.getString("password");
				matricula=rs.getString("matricula");
				cuentaHallada= new Cuenta(usuario,password,matricula);			
			}
			rs.close();
			ps.close();
			conexion.close();
			
		} catch (SQLException e) {
			try {
				rs.close();
				ps.close();
				conexion.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return cuentaHallada;
	}
	@Override
	public int insertarUsuario(Cuenta usuario) {
		int verificar=0;
		PreparedStatement ps=null;

		String sql="INSERT INTO usuarioestudiante(correo_institucional,password,matricula) VALUES(?,?,?);";
		if(conexionTransferida==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);

			ps.setString(1, usuario.getCorreoInstitucional());
			ps.setString(2, usuario.getPassword());
			ps.setString(3, usuario.getMatricula());
			
			try{
				verificar=ps.executeUpdate();
			}catch(SQLException e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Los datos ya estan registrados");
			
			}finally {
				ps.close();
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				if(conexionTransferida==false)
					conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
		return verificar;
	}
	
	public int insertarUsuarioEstudiante(Estudiante estudiante,Cuenta cuenta) {
		  int verificar = 0;
			EstudianteIMPA estudianteDAO; //declara
			
			try {
				conexion=admin.dameConexion();
				conexion.setAutoCommit(false);
				estudianteDAO = new EstudianteIMPA(conexion);
				
				verificar = estudianteDAO.insertar(estudiante);
				
				verificar+= estudianteDAO.insertarUsuario(cuenta);
				
				if(verificar==2)
					conexion.commit();
				else
					conexion.rollback();
			}catch(SQLException e) {
				try {
					conexion.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}finally {			
				try {
					conexion.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		  
		  return verificar;
	  }
  @Override
  public List<Estudiante> consultar() {
    List<Estudiante> estudiantes = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "SELECT matricula, nombre,apellidop, correo_institucional, "
           + "apellidom, correo_personal, numero_casa, numero_celular FROM estudiantes;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      rs = ps.executeQuery();
      estudiantes = new ArrayList<Estudiante>();
      while (rs.next()) {
        Estudiante estudiante = new Estudiante();
        estudiante.setMatricula(rs.getString("matricula"));
        estudiante.setNombre(rs.getString("nombre"));
        estudiante.setApellidoP(rs.getString("apellidop"));
        estudiante.setCorreoInstitucional(rs.getString("correo_institucional"));
        estudiante.setApellidoM(rs.getString("apellidom"));
        estudiante.setCorreoPersonal(rs.getString("correo_personal"));
        estudiante.setNumCasa(rs.getString("numero_casa"));
        estudiante.setNumCelular(rs.getString("numero_celular"));
        estudiantes.add(estudiante);
      }
      ps.close();
      rs.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return estudiantes;
  }

  @Override
  public Estudiante consultarEstudiante(Estudiante estudiante) {
    Estudiante estudianteHallado = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "SELECT matricula, nombre,apellidop, correo_institucional, "
            + "apellidom, correo_personal, numero_casa, numero_celular FROM estudiantes"
            + " WHERE matricula=?;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, estudiante.getMatricula());
      rs = ps.executeQuery();
      if (rs.next()) {
        estudianteHallado = new Estudiante();
        estudianteHallado.setMatricula(rs.getString("matricula"));
        estudianteHallado.setNombre(rs.getString("nombre"));
        estudianteHallado.setApellidoP(rs.getString("apellidop"));
        estudianteHallado.setApellidoM(rs.getString("apellidom"));
        estudianteHallado.setCorreoPersonal(rs.getString("correo_personal"));
        estudianteHallado.setCorreoInstitucional(rs.getString("correo_institucional"));
        estudianteHallado.setNumCasa(rs.getString("numero_casa"));
        estudianteHallado.setNumCelular(rs.getString("numero_celular"));
      }
      ps.close();
      rs.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return estudianteHallado;
  }
  
  @Override
  public Estudiante consultarEstudianteAcceso(Estudiante estudiante) {
    Estudiante estudianteHallado = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "SELECT matricula, nombre,apellidop, correo_institucional, "
            + "apellidom, correo_personal, numero_casa, numero_celular FROM estudiantes"
            + " WHERE correo_institucional=?;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, estudiante.getCorreoInstitucional());
      rs = ps.executeQuery();
      if (rs.next()) {
        estudianteHallado = new Estudiante();
        estudianteHallado.setMatricula(rs.getString("matricula"));
        estudianteHallado.setNombre(rs.getString("nombre"));
        estudianteHallado.setApellidoP(rs.getString("apellidop"));
        estudianteHallado.setApellidoM(rs.getString("apellidom"));
        estudianteHallado.setCorreoPersonal(rs.getString("correo_personal"));
        estudianteHallado.setCorreoInstitucional(rs.getString("correo_institucional"));
        estudianteHallado.setNumCasa(rs.getString("numero_casa"));
        estudianteHallado.setNumCelular(rs.getString("numero_celular"));
      }
      ps.close();
      rs.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return estudianteHallado;
  }
  
  @Override
  public ArrayList<Historiales> consultarHistorial(Estudiante estudiante) {
    Historiales estudianteHallado = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    ArrayList<Historiales> lista = new ArrayList<>();
    String sql = "SELECT h.tipo_semestre,h.matricula,m.nombre,h.status FROM historiales h,materias m" +
            " WHERE matricula=? AND m.cve_materia=h.cve_materia;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, estudiante.getMatricula());
      rs = ps.executeQuery();
      while (rs.next()) {
        estudianteHallado = new Historiales();
        estudianteHallado.setSemestre(rs.getString("tipo_semestre"));
        estudianteHallado.setMatricula(rs.getString("matricula"));
        estudianteHallado.setCve_materia(rs.getString("nombre"));
        estudianteHallado.setStatus(rs.getString("status"));
        lista.add(estudianteHallado);
      }
      ps.close();
      rs.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return lista;
  }
  
  /*@Override
  public Historiales consultarHistorial(Historiales estudiante) {
    Historiales estudianteHallado = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "SELECT tipo_semestre, matricula, cve_materia, status FROM historiales"
            + " WHERE matricula=?;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, estudiante.getMatricula());
      rs = ps.executeQuery();
      if (rs.next()) {
        estudianteHallado = new Historiales();
        estudianteHallado.setSemestre(rs.getString("tipo_semestre"));
        estudianteHallado.setMatricula(rs.getString("matricula"));
        estudianteHallado.setCve_materia(rs.getString("cve_materia"));
        estudianteHallado.setStatus(rs.getString("status"));
      }
      ps.close();
      rs.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return estudianteHallado;
  }*/
}
