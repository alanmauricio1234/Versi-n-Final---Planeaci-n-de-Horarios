package basedatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Criterio;

public class CriteriosImp implements CriteriosDao {
  private AdminBD admin;
  private Connection conexion;
  
  public CriteriosImp() {
    admin = new AdminBD();
    conexion = null;
  }
  
  @Override
  public int insertarCriterios(Criterio criterio) {
    int contador = 0;
    PreparedStatement ps = null;
    String sql = "INSERT INTO criterios(semestre) VALUES(?);";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, criterio.getSemestre());
      contador = ps.executeUpdate();
      ps.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return contador;
  }

  @Override
  public int eliminarCriterios() {
    int contador = 0;
    PreparedStatement ps = null;
    String sql = "DELETE FROM criterios;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      contador = ps.executeUpdate();
      ps.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    return contador;
  }
  
  /**Consultar.*/
  public List<Criterio> consultar() {
    List<Criterio> criterios = new ArrayList<Criterio>();
    PreparedStatement ps = null;
    ResultSet rs = null;
    Criterio criterio = null;
    String sql = "SELECT semestre FROM criterios;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      rs = ps.executeQuery();
      while (rs.next()) {
        criterio = new Criterio();
        criterio.setSemestre(rs.getString("semestre"));
        criterios.add(criterio);
      }
      ps.close();
      rs.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return criterios;
  }

}
