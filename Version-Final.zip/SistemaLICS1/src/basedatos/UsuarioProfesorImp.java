package basedatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import modelo.UsuarioProfesor;

public class UsuarioProfesorImp implements UsuarioProfesorDAO {
  private AdminBD admin;
  private Connection conexion;
  private boolean conexionTransferida;
  
  public UsuarioProfesorImp() {
    admin = new AdminBD();
    conexion = null;
    conexionTransferida = false;
  }
  
  public UsuarioProfesorImp(Connection conexion) {
    this.conexion = conexion;
    conexionTransferida = true;
  }
  
  @Override
  public int insertar(UsuarioProfesor usuario) {
    int contador = 0;
    PreparedStatement ps = null;
    String sql = "INSERT INTO usuarioprofesor(correo_institucional, no_trabajador,"
           + "password) VALUES(?,?,?)";
    if (conexionTransferida == false) {
      conexion = admin.dameConexion();
    }
    try {
      ps = conexion.prepareStatement(sql);
      ps.setString(1, usuario.getCorreoInstitucional());
      ps.setString(2, usuario.getNumeroTrabajador());
      ps.setString(3, usuario.getPassword());
      contador = ps.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        ps.close();
        if (conexionTransferida == false) {
          admin.cerrarConexion(conexion);
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    
    return contador;
  }

  @Override
  public UsuarioProfesor consultarUsuario(UsuarioProfesor usuario) {
    UsuarioProfesor usuarioHallado = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "SELECT correo_institucional, no_trabajador, password "
           + "FROM usuarioprofesor WHERE correo_institucional=? AND password=?;";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, usuario.getCorreoInstitucional());
      ps.setString(2, usuario.getPassword());
      rs = ps.executeQuery();
      if (rs.next()) {
        usuarioHallado = new UsuarioProfesor();
        usuarioHallado.setCorreoInstitucional(rs.getString("correo_institucional"));
        usuarioHallado.setNumeroTrabajador(rs.getString("no_trabajador"));
        usuarioHallado.setPassword(rs.getString("password"));
      }
      rs.close();
      ps.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return usuarioHallado;
  }

  @Override
  public int eliminar(UsuarioProfesor usuario) {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public List<UsuarioProfesor> consultar() {
    // TODO Auto-generated method stub
    return null;
  }

}
