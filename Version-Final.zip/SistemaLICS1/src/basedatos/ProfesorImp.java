package basedatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import modelo.Profesor;
import modelo.UsuarioProfesor;

public class ProfesorImp implements ProfesorDAO {
  private AdminBD admin;
  private Connection conexion;
  private boolean conexionTranferida;
  
  /**Constructor de la clase.*/
  public ProfesorImp() {
    admin = new AdminBD();
    conexion = null;
    conexionTranferida = false;
  }
  
  public ProfesorImp(Connection conexion) {
    this.conexion = conexion;
    conexionTranferida = true;
  }
  
  @Override
  public int insertar(Profesor profesor) {
    int contador = 0;
    PreparedStatement ps = null;
    String sql = "INSERT INTO profesor(no_trabajador, nombre, apellidop, apellidom,"
           + "correo_institucional, correo_personal, colegio, plantel, academia, cubiculo,"
           + "no_celular, extension) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
    if (conexionTranferida == false) {
      conexion = admin.dameConexion();
    }
    try {
      ps = conexion.prepareStatement(sql);
      ps.setString(1, profesor.getNumTrabajador());
      ps.setString(2, profesor.getNombre());
      ps.setString(3, profesor.getApellidoP());
      ps.setString(4, profesor.getApellidoM());
      ps.setString(5, profesor.getCorreoInstitucional());
      ps.setString(6, profesor.getCorreoPersonal());
      ps.setString(7, profesor.getColegioAdscripcion());
      ps.setString(8, profesor.getPlantelAdscripcion());
      ps.setString(9, profesor.getAcademia());
      ps.setString(10, profesor.getCubiculo());
      ps.setString(11, profesor.getNumCelular());
      ps.setString(12, profesor.getExtension());
      contador = ps.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      try {
        ps.close();
        if (conexionTranferida == false) {
          conexion.close();
        }
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    
    return contador;
  }
  
  /**Transacci�n.*/
  public void insertarTransaccion(Profesor profesor, UsuarioProfesor usuario) {
    int contador = 0;
    ProfesorImp profesorDAO;
    UsuarioProfesorImp usuarioDAO;
    try {
      conexion = admin.dameConexion();
      conexion.setAutoCommit(false);
      profesorDAO = new ProfesorImp(conexion);
      contador = profesorDAO.insertar(profesor);
      //Insertamos al usuario
      usuarioDAO = new UsuarioProfesorImp(conexion);
      contador += usuarioDAO.insertar(usuario);
      //Comprobamos que la transacci�n este bien hecha
      if (contador == 2) {
        conexion.commit();
      } else {
        conexion.rollback();
      }
      //Cerramos
      
    } catch (SQLException e) {
      try {
        conexion.rollback();
      } catch (SQLException e1) {
        // TODO Auto-generated catch block
        e1.printStackTrace();
      }
      e.printStackTrace();
    } finally {
      admin.cerrarConexion(conexion);
    }
    
  }

  @Override
  public int eliminar(Profesor profesor) {
    // TODO Auto-generated method stub
    return 0;
  }

  @Override
  public List<Profesor> consultar() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Profesor consultarProfesor(Profesor profesor) {
    Profesor profesorH = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "SELECT no_trabajador, nombre, apellidop, apellidom "
           + "FROM profesor WHERE no_trabajador=?";
    try {
      conexion = admin.dameConexion();
      ps = conexion.prepareStatement(sql);
      ps.setString(1, profesor.getNumTrabajador());
      rs = ps.executeQuery();
      if (rs.next()) {
        profesorH = new Profesor();
        profesorH.setNumTrabajador(rs.getString("no_trabajador"));
        profesorH.setNombre(rs.getString("nombre"));
        profesorH.setApellidoP(rs.getString("apellidop"));
        profesorH.setApellidoM(rs.getString("apellidom"));
      }
      rs.close();
      ps.close();
      admin.cerrarConexion(conexion);
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    return profesorH;
  }

}
