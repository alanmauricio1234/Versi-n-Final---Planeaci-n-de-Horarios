package basedatos;

import java.util.ArrayList;
import java.util.List;

import modelo.Cuenta;
import modelo.Estudiante;
import modelo.Historiales;

public interface EstudianteIMP {
  public int insertar(Estudiante estudiante);
  
  public int insertarHistorial(Historiales historial);
  
  public Cuenta consultar(Cuenta cuenta);
  
  public int insertarUsuario(Cuenta usuario);
  
  public List<Estudiante> consultar();
  
  public int contarCursando(Estudiante estudiante);
  
  public Estudiante consultarEstudiante(Estudiante estudiante);
  
  public int insertarUsuarioEstudiante(Estudiante estudiante,Cuenta cuenta);
  
  public ArrayList<Historiales> consultarHistorial(Estudiante estudiante);
  
  public Estudiante consultarEstudianteAcceso(Estudiante estudiante);
}
