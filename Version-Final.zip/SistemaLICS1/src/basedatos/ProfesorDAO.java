package basedatos;

import java.util.List;

import modelo.Profesor;

public interface ProfesorDAO {
  public int insertar(Profesor profesor);
  
  public int eliminar(Profesor profesor);
  
  public List<Profesor> consultar();
  
  public Profesor consultarProfesor(Profesor profesor);
}
