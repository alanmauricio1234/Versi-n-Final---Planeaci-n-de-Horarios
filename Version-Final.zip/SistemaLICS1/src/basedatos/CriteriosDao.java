package basedatos;


import java.util.List;

import modelo.Criterio;

public interface CriteriosDao {
  public int insertarCriterios(Criterio criterio);
  
  public int eliminarCriterios();
  
  public List<Criterio> consultar();
}
