package basedatos;

import java.util.ArrayList;

import modelo.Estudiante;
import modelo.Inscripcion;
import modelo.Recomendaciones;

public interface InscripcionDAO {
  public int insertar(Inscripcion inscripcion, Estudiante estudiante, int i);
  
  public int borrar(Inscripcion inscripcion);
  
  public ArrayList<Inscripcion> consultar();
  
  public ArrayList<Recomendaciones> conteoInscripciones();
  
}
