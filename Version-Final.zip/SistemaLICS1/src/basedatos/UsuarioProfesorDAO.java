package basedatos;

import java.util.List;

import modelo.UsuarioProfesor;

public interface UsuarioProfesorDAO {
  public int insertar(UsuarioProfesor usuario);
  
  public int eliminar(UsuarioProfesor usuario);
  
  public List<UsuarioProfesor> consultar();
  
  public UsuarioProfesor consultarUsuario(UsuarioProfesor usuario);
}
