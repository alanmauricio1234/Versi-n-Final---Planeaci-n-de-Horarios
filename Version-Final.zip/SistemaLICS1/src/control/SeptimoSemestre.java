package control;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class SeptimoSemestre extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	EstudianteIMPA invocar = new EstudianteIMPA();
	private String semestre;
    private String matricula;
	private String cve_materia;
	private String status;

	private JPanel contentPane;
    public static JTextField reciboNombre;
    public static JTextField reciboContrasena;
    public static JTextField Arquitectura;
    public static JTextField Lenguajes;
    public static JTextField Tecnicas;
    public static JTextField Dise�o;
    public static JTextField Construccion;
    public static  JTextField Metodologia;

	/**
	 * Create the frame.
	 */
	public SeptimoSemestre(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		reciboNombre = new JTextField(estudiante.getNombre());
		reciboNombre.setEditable(false);
		reciboNombre.setBounds(98, 11, 200, 20);
		contentPane.add(reciboNombre);
		reciboNombre.setColumns(10);
		
		reciboContrasena = new JTextField(estudiante.getMatricula());
		reciboContrasena.setEditable(false);
		reciboContrasena.setBounds(98, 53, 200, 20);
		contentPane.add(reciboContrasena);
		reciboContrasena.setColumns(10);
		
		Arquitectura = new JTextField();
		Arquitectura.setText("Arquitectura de Computdaoras");
		Arquitectura.setBounds(10, 261, 178, 20);
		contentPane.add(Arquitectura);
		Arquitectura.setBackground(Color.red);
		Arquitectura.setColumns(10);
		
		JList list = new JList();
		list.setBounds(226, 150, 43, -44);
		contentPane.add(list);
		
		JComboBox SemestreARQ = new JComboBox();
		SemestreARQ.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreARQ.setBounds(441, 260, 89, 22);
		contentPane.add(SemestreARQ);
		SemestreARQ.setVisible(false);
		
	    JComboBox Colores = new JComboBox();
		Colores.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores.getSelectedIndex();
		        if( indice == 1){
		        	Arquitectura.setBackground(Color.green);
		        	SemestreARQ.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Arquitectura.setBackground(Color.yellow);
		            	SemestreARQ.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Arquitectura.setBackground(Color.red);
		            		SemestreARQ.setVisible(false);
		            	}
		            }
		        }		        
			}
		});
		Colores.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores.setBounds(215, 261, 150, 20);
		contentPane.add(Colores);
		
		JLabel lblAlumno = new JLabel("ALUMNO");
		lblAlumno.setBounds(10, 14, 57, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblMatricula = new JLabel("MATRICULA");
		lblMatricula.setBounds(10, 56, 77, 14);
		contentPane.add(lblMatricula);
		
		JLabel lblMarcaConVerde = new JLabel("Marca con Verde las materias que has certificado");
		lblMarcaConVerde.setBounds(10, 81, 299, 14);
		contentPane.add(lblMarcaConVerde);
		
		JLabel lblMarcaConAmarillo = new JLabel("Marca con Amarillo las materias que estas cursando");
		lblMarcaConAmarillo.setBounds(10, 106, 310, 14);
		contentPane.add(lblMarcaConAmarillo);
		
		Lenguajes = new JTextField();
		Lenguajes.setText("Lenguajes de Programacion");
		Lenguajes.setColumns(10);
		Lenguajes.setBounds(10, 310, 178, 20);
		Lenguajes.setBackground(Color.red);
		contentPane.add(Lenguajes);
		
		JComboBox SemestreLEN = new JComboBox();
		SemestreLEN.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreLEN.setBounds(441, 309, 89, 22);
		contentPane.add(SemestreLEN);
		SemestreLEN.setVisible(false);
		
		final JComboBox Colores2 = new JComboBox();
		Colores2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores2.getSelectedIndex();
		        if( indice == 1){
		        	Lenguajes.setBackground(Color.green);
		        	SemestreLEN.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Lenguajes.setBackground(Color.yellow);
		                SemestreLEN.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Lenguajes.setBackground(Color.red);
		            		SemestreLEN.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores2.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores2.setBounds(215, 310, 150, 20);
		contentPane.add(Colores2);
		
		JComboBox SemestreTEC = new JComboBox();
		SemestreTEC.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreTEC.setBounds(441, 362, 89, 22);
		contentPane.add(SemestreTEC);
		SemestreTEC.setVisible(false);
		
		final JComboBox Colores3 = new JComboBox();
		Colores3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores3.getSelectedIndex();
		        if( indice == 1){
		        	Tecnicas.setBackground(Color.green);
		        	SemestreTEC.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Tecnicas.setBackground(Color.yellow);
		                SemestreTEC.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Tecnicas.setBackground(Color.red);
		            		SemestreTEC.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores3.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores3.setBounds(215, 363, 150, 20);
		contentPane.add(Colores3);
		
		Tecnicas = new JTextField();
		Tecnicas.setText("Tecnicas de Pruebas de Software");
		Tecnicas.setBounds(10, 363, 178, 20);
		contentPane.add(Tecnicas);
		Tecnicas.setBackground(Color.red);
		Tecnicas.setColumns(10);
		
		JComboBox SemestreDIS = new JComboBox();
		SemestreDIS.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreDIS.setBounds(441, 412, 89, 22);
		contentPane.add(SemestreDIS);
		SemestreDIS.setVisible(false);
		
		Dise�o = new JTextField();
		Dise�o.setBounds(10, 413, 178, 20);
		Dise�o.setText("Dise\u00F1o de Software");
		contentPane.add(Dise�o);
		Dise�o.setBackground(Color.red);
		Dise�o.setColumns(10);
		
		
		final JComboBox Colores4 = new JComboBox();
		Colores4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores4.getSelectedIndex();
		        if( indice == 1){
		        	Dise�o.setBackground(Color.green);
		        	SemestreDIS.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Dise�o.setBackground(Color.yellow);
		                SemestreDIS.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Dise�o.setBackground(Color.red);
		            		SemestreDIS.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores4.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores4.setBounds(215, 413, 150, 20);
		contentPane.add(Colores4);
		
		Metodologia = new JTextField();
		Metodologia.setText("Metodologia de la Investigacion");
		Metodologia.setColumns(10);
		Metodologia.setBackground(Color.RED);
		Metodologia.setBounds(10, 462, 178, 20);
		contentPane.add(Metodologia);
		
		JComboBox SemestreMET = new JComboBox();
		SemestreMET.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreMET.setBounds(441, 461, 89, 22);
		contentPane.add(SemestreMET);
		SemestreMET.setVisible(false);
		
		JComboBox Colores5 = new JComboBox();
		Colores5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores5.getSelectedIndex();
		        if( indice == 1){
		        	Metodologia.setBackground(Color.green);
		        	SemestreMET.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Metodologia.setBackground(Color.yellow);
		                SemestreMET.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Metodologia.setBackground(Color.red);
		            		SemestreMET.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores5.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores5.setBounds(215, 462, 150, 20);
		contentPane.add(Colores5);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(Colores.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-14";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if(SemestreARQ.getSelectedIndex() == 0 || SemestreARQ.getSelectedIndex() == 1 || SemestreARQ.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-14";
			            	
			            	if( Colores.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreARQ.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores2.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-15";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreLEN.getSelectedIndex()== 0 || SemestreLEN.getSelectedIndex() == 1 || SemestreTEC.getSelectedIndex() == 2) {	
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-15";
			            	
			            	if( Colores2.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreLEN.getSelectedItem();
								status = "certificado";
			            	}else {
			            		if( Colores2.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores3.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-16";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreTEC.getSelectedIndex() == 0 || SemestreTEC.getSelectedIndex() == 1 || SemestreTEC.getSelectedIndex() == 2) {	
							String semestre = null;
							
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-16";
			            	
			            	if( Colores3.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreTEC.getSelectedItem();
								status="certificado";
			            	}else {
								if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
								}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores4.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-17";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreDIS.getSelectedIndex( ) == 0 || SemestreDIS.getSelectedIndex() == 1 || SemestreDIS.getSelectedIndex() == 2) {	
							
							String semestre = null;
		
								matricula = Registro.textMatricula.getText();
				            	cve_materia="1-CT-IS-17";
				            	
				            	if( Colores4.getSelectedIndex() == 1 ) {
									semestre = (String)SemestreDIS.getSelectedItem();
									status="certificado";
				            	}else {
									if( Colores4.getSelectedIndex() == 0 ) {
									semestre = "2019-II";
								    status = "No certificado";
									}
								}
				            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
				            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores5.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-18";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if(SemestreMET.getSelectedIndex() == 0 || SemestreMET.getSelectedIndex() == 1 || SemestreMET.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-18";
			            	
			            	if( Colores5.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreMET.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores5.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					JOptionPane.showMessageDialog(null, "Registro exitoso");
					OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
					visible.setVisible(true);
					setVisible(false);
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Registro fallido");
				}
			}
		});
		btnRegistrar.setBounds(10, 540, 139, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblMateriasQueNo = new JLabel("Materias que NO has cursado o NO has pasado dejalas en ROJO");
		lblMateriasQueNo.setFont(new Font("Stencil", Font.PLAIN, 12));
		lblMateriasQueNo.setBounds(10, 131, 424, 22);
		contentPane.add(lblMateriasQueNo);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionHistorial visible = new OpcionHistorial(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnRegresar.setBounds(426, 540, 104, 23);
		contentPane.add(btnRegresar);
		
		JLabel lblSiNoHas = new JLabel("Si no has CURSADO o CERTIFICADO ninguna solo OPRIME registrar");
		lblSiNoHas.setFont(new Font("Stencil", Font.PLAIN, 16));
		lblSiNoHas.setBounds(7, 164, 558, 36);
		contentPane.add(lblSiNoHas);
		
		JLabel lblEnCasoDe = new JLabel("En caso de optimir certificado");
		lblEnCasoDe.setBounds(426, 199, 167, 14);
		contentPane.add(lblEnCasoDe);
		
		JLabel lblInicaEnQue = new JLabel("indica en que semestre\r\n");
		lblInicaEnQue.setBounds(426, 224, 167, 14);
		contentPane.add(lblInicaEnQue);
		
	}
}