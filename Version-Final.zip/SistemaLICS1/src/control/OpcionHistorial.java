package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class OpcionHistorial extends JFrame {

	private JPanel contentPane;
	ArrayList<Historiales> lista = new ArrayList<>();
	/**
	 * Create the frame.
	 */
	public OpcionHistorial(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 395);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Ingresa a todas las opciones ");
		lblNewLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 11, 411, 23);
		contentPane.add(lblNewLabel);
		
		JButton btnCicloBasico = new JButton("Ciclo Basico");
		btnCicloBasico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Basico visible = new Basico(estudiante, historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnCicloBasico.setBounds(10, 151, 126, 23);
		contentPane.add(btnCicloBasico);
		
		JButton btntoSemestre = new JButton("5to Semestre");
		btntoSemestre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				QuintoSemestre visible = new QuintoSemestre(estudiante, historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btntoSemestre.setBounds(210, 151, 126, 23);
		contentPane.add(btntoSemestre);
		
		JButton btntoSemestre_1 = new JButton("6to Semestre");
		btntoSemestre_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SextoSemestre visible = new SextoSemestre(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btntoSemestre_1.setBounds(10, 195, 126, 23);
		contentPane.add(btntoSemestre_1);
		
		JButton btntoSemestre_2 = new JButton("7to Semestre");
		btntoSemestre_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SeptimoSemestre visible = new SeptimoSemestre(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btntoSemestre_2.setBounds(210, 195, 126, 23);
		contentPane.add(btntoSemestre_2);
		
		JButton btnvoSemestre = new JButton("8vo Semestre");
		btnvoSemestre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OctavoSemestre visible = new OctavoSemestre(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnvoSemestre.setBounds(10, 246, 126, 23);
		contentPane.add(btnvoSemestre);
		
		JButton btnvoSemestre_1 = new JButton("9vo Semestre");
		btnvoSemestre_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NovenoSemestre visible = new NovenoSemestre(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnvoSemestre_1.setBounds(210, 246, 126, 23);
		contentPane.add(btnvoSemestre_1);
		
		JButton btndoSemestre = new JButton("10do Semestre");
		btndoSemestre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DecimoSemestre visible = new DecimoSemestre(estudiante, historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btndoSemestre.setBounds(10, 294, 126, 23);
		contentPane.add(btndoSemestre);
		
		JButton btnMenuPrincipal = new JButton("Menu Principal");
		btnMenuPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Bienvenida visible = new Bienvenida();
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnMenuPrincipal.setBounds(273, 322, 126, 23);
		contentPane.add(btnMenuPrincipal);
		
		JLabel lblParaSaberQue = new JLabel("para saber que ha pasado con tu historial Academico");
		lblParaSaberQue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 14));
		lblParaSaberQue.setBounds(10, 43, 411, 23);
		contentPane.add(lblParaSaberQue);
		
		JLabel lblPorFavorRellena = new JLabel("Por Favor rellena todo tu historial ya que");
		lblPorFavorRellena.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblPorFavorRellena.setBounds(10, 79, 411, 23);
		contentPane.add(lblPorFavorRellena);
		
		JLabel lblEsLanica = new JLabel("es la \u00FAnica oportunidad que tendras de rellenarlo.");
		lblEsLanica.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 20));
		lblEsLanica.setBounds(10, 113, 411, 23);
		contentPane.add(lblEsLanica);
		
		
	}
}
