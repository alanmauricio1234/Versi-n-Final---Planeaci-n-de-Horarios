package control;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class OctavoSemestre extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	EstudianteIMPA invocar = new EstudianteIMPA();
	private String semestre;
    private String matricula;
	private String cve_materia;
	private String status;

	private JPanel contentPane;
    public static JTextField reciboNombre;
    public static JTextField reciboContrasena;
    public static JTextField Redes;
    public static JTextField Normatividad;
    public static JTextField Arquitectura;
    public static JTextField Construccion;

	/**
	 * Create the frame.
	 */
	public OctavoSemestre(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 526);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		reciboNombre = new JTextField(estudiante.getNombre());
		reciboNombre.setEditable(false);
		reciboNombre.setBounds(98, 11, 200, 20);
		contentPane.add(reciboNombre);
		reciboNombre.setColumns(10);
		
		reciboContrasena = new JTextField(estudiante.getMatricula());
		reciboContrasena.setEditable(false);
		reciboContrasena.setBounds(98, 53, 200, 20);
		contentPane.add(reciboContrasena);
		reciboContrasena.setColumns(10);
		
		Redes = new JTextField();
		Redes.setText("Redes de Computdaoras");
		Redes.setBounds(10, 261, 178, 20);
		contentPane.add(Redes);
		Redes.setBackground(Color.red);
		Redes.setColumns(10);
		
		JList list = new JList();
		list.setBounds(226, 150, 43, -44);
		contentPane.add(list);
		
		JComboBox SemestreRED = new JComboBox();
		SemestreRED.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreRED.setBounds(441, 260, 89, 22);
		contentPane.add(SemestreRED);
		SemestreRED.setVisible(false);
		
	    JComboBox Colores = new JComboBox();
		Colores.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores.getSelectedIndex();
		        if( indice == 1){
		        	Redes.setBackground(Color.green);
		        	SemestreRED.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Redes.setBackground(Color.yellow);
		            	SemestreRED.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Redes.setBackground(Color.red);
		            		SemestreRED.setVisible(false);
		            	}
		            }
		        }		        
			}
		});
		Colores.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores.setBounds(215, 261, 150, 20);
		contentPane.add(Colores);
		
		JLabel lblAlumno = new JLabel("ALUMNO");
		lblAlumno.setBounds(10, 14, 57, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblMatricula = new JLabel("MATRICULA");
		lblMatricula.setBounds(10, 56, 77, 14);
		contentPane.add(lblMatricula);
		
		JLabel lblMarcaConVerde = new JLabel("Marca con Verde las materias que has certificado");
		lblMarcaConVerde.setBounds(10, 81, 299, 14);
		contentPane.add(lblMarcaConVerde);
		
		JLabel lblMarcaConAmarillo = new JLabel("Marca con Amarillo las materias que estas cursando");
		lblMarcaConAmarillo.setBounds(10, 106, 310, 14);
		contentPane.add(lblMarcaConAmarillo);
		
		Normatividad = new JTextField();
		Normatividad.setText("Normatividad y Legislacion");
		Normatividad.setColumns(10);
		Normatividad.setBounds(10, 310, 178, 20);
		Normatividad.setBackground(Color.red);
		contentPane.add(Normatividad);
		
		JComboBox SemestreNOR = new JComboBox();
		SemestreNOR.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreNOR.setBounds(441, 309, 89, 22);
		contentPane.add(SemestreNOR);
		SemestreNOR.setVisible(false);
		
		final JComboBox Colores2 = new JComboBox();
		Colores2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores2.getSelectedIndex();
		        if( indice == 1){
		        	Normatividad.setBackground(Color.green);
		        	SemestreNOR.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Normatividad.setBackground(Color.yellow);
		                SemestreNOR.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Normatividad.setBackground(Color.red);
		            		SemestreNOR.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores2.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores2.setBounds(215, 310, 150, 20);
		contentPane.add(Colores2);
		
		JComboBox SemestreARQSO = new JComboBox();
		SemestreARQSO.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreARQSO.setBounds(441, 367, 89, 22);
		contentPane.add(SemestreARQSO);
		SemestreARQSO.setVisible(false);
		
		final JComboBox Colores3 = new JComboBox();
		Colores3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores3.getSelectedIndex();
		        if( indice == 1){
		        	Arquitectura.setBackground(Color.green);
		        	SemestreARQSO.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Arquitectura.setBackground(Color.yellow);
		                SemestreARQSO.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Arquitectura.setBackground(Color.red);
		            		SemestreARQSO.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores3.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores3.setBounds(215, 368, 150, 20);
		contentPane.add(Colores3);
		
		Arquitectura = new JTextField();
		Arquitectura.setText("Arquitectura de Software");
		Arquitectura.setBounds(10, 368, 178, 20);
		contentPane.add(Arquitectura);
		Arquitectura.setBackground(Color.red);
		Arquitectura.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(Colores.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-19";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if(SemestreRED.getSelectedIndex() == 0 || SemestreRED.getSelectedIndex() == 1 || SemestreRED.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-19";
			            	
			            	if( Colores.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreRED.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores2.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-20";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreNOR.getSelectedIndex()== 0 || SemestreNOR.getSelectedIndex() == 1 || SemestreARQSO.getSelectedIndex() == 2) {	
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-20";
			            	
			            	if( Colores2.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreNOR.getSelectedItem();
								status = "certificado";
			            	}else {
			            		if( Colores2.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores3.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-21";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreARQSO.getSelectedIndex() == 0 || SemestreARQSO.getSelectedIndex() == 1 || SemestreARQSO.getSelectedIndex() == 2) {	
							String semestre = null;
							
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-21";
			            	
			            	if( Colores3.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreARQSO.getSelectedItem();
								status="certificado";
			            	}else {
								if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
								}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
						
						}
					}
	
					JOptionPane.showMessageDialog(null, "Registro exitoso");
					OpcionHistorial visible = new OpcionHistorial(estudiante,historial);
					visible.setVisible(true);
					setVisible(false);
				
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Registro fallido");
				}
			}
		});
		btnRegistrar.setBounds(10, 428, 139, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblMateriasQueNo = new JLabel("Materias que NO has cursado o NO has pasado dejalas en ROJO");
		lblMateriasQueNo.setFont(new Font("Stencil", Font.PLAIN, 12));
		lblMateriasQueNo.setBounds(10, 131, 424, 22);
		contentPane.add(lblMateriasQueNo);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionHistorial visible = new OpcionHistorial(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnRegresar.setBounds(424, 428, 104, 23);
		contentPane.add(btnRegresar);
		
		JLabel lblSiNoHas = new JLabel("Si no has CURSADO o CERTIFICADO ninguna solo OPRIME registrar");
		lblSiNoHas.setFont(new Font("Stencil", Font.PLAIN, 16));
		lblSiNoHas.setBounds(7, 164, 558, 36);
		contentPane.add(lblSiNoHas);
		
		JLabel lblEnCasoDe = new JLabel("En caso de optimir certificado");
		lblEnCasoDe.setBounds(426, 199, 167, 14);
		contentPane.add(lblEnCasoDe);
		
		JLabel lblInicaEnQue = new JLabel("indica en que semestre\r\n");
		lblInicaEnQue.setBounds(426, 224, 167, 14);
		contentPane.add(lblInicaEnQue);
		
	}
}