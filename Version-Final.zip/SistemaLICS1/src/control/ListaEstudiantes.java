package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import modelo.Estudiante;
import modelo.Profesor;

import javax.swing.JButton;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ListaEstudiantes extends JFrame {

  private JPanel contentPane;
  private DefaultTableModel modelo;
  private JTable tblDatos;
  private JPanel panel;
  private JButton btnRegresar;



  /**
   * Create the frame.
   */
  public ListaEstudiantes(List<Estudiante> estudiantes, Profesor profesor) {
    setTitle("Registrados");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 632, 333);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JLabel lblLosEstudiantesRegistrados = new JLabel("Los estudiantes registrados");
    lblLosEstudiantesRegistrados.setHorizontalAlignment(SwingConstants.CENTER);
    contentPane.add(lblLosEstudiantesRegistrados, BorderLayout.NORTH);
    
    JScrollPane scrollPane = new JScrollPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);
    
    tblDatos = new JTable();
    tblDatos.setModel(new DefaultTableModel(
        new Object[][] {
        },
          new String[] {
            "Matricula", "Nombre", "Apellido Paterno", "Apellido Materno", 
            "Correo Institucional", "Correo Personal", "Numero Celular", "Numero Casa"
          }
    ));
    scrollPane.setViewportView(tblDatos);
    agregarElementos(estudiantes);
    panel = new JPanel();
    panel.setBorder(new LineBorder(new Color(0, 0, 0)));
    contentPane.add(panel, BorderLayout.SOUTH);
    
    btnRegresar = new JButton("Regresar");
    btnRegresar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        LoginProfesor login = new LoginProfesor(profesor);
        setVisible(false);
        login.setVisible(true);
      }
    });
    panel.add(btnRegresar);
  }
  
  private void agregarElementos(List<Estudiante> estudiantes) {
    modelo = (DefaultTableModel) tblDatos.getModel();
    String[] fila = new String[8];
    Estudiante estudiante = null;
    for (int i = 0; i < estudiantes.size(); i++) {
      estudiante = estudiantes.get(i);
      fila[0] = estudiante.getMatricula();
      fila[1] = estudiante.getNombre();
      fila[2] = estudiante.getApellidoP();
      fila[3] = estudiante.getApellidoM();
      fila[4] = estudiante.getCorreoInstitucional();
      fila[5] = estudiante.getCorreoPersonal();
      fila[6] = estudiante.getNumCelular();
      fila[7] = estudiante.getNumCasa();
      //Agregamos la fila
      modelo.addRow(fila);
    }
    tblDatos.setModel(modelo);
  }

}
