package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import basedatos.CriteriosImp;
import modelo.Criterio;
import modelo.Materia;
import modelo.Profesor;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import net.miginfocom.swing.MigLayout;

public class GenerarEncuesta extends JFrame {

  private JPanel contentPane;
  private JTable tblDatos;
  private List<Criterio> criterios;
  private CriteriosImp criteriosImp = new CriteriosImp();
  private DefaultTableModel modelo;



  /**
   * Create the frame.
   */
  public GenerarEncuesta(Profesor profesor) {
    setTitle("Generar Encuesta");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 579, 323);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JLabel lblEligeLosSemestres = new JLabel("Elige los semestres");
    lblEligeLosSemestres.setHorizontalAlignment(SwingConstants.CENTER);
    contentPane.add(lblEligeLosSemestres, BorderLayout.NORTH);
    
    JScrollPane scrollPane = new JScrollPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);
    
    tblDatos = new JTable();
    tblDatos.setModel(new DefaultTableModel(
        new Object[][] {
        },
        new String[] {
          "Semestre o Optativa"
        }
    ));
    scrollPane.setViewportView(tblDatos);
    criterios = criteriosImp.consultar();
    if (criterios == null) {
      criterios = new ArrayList<Criterio>();
    } else {
      modelo = (DefaultTableModel) tblDatos.getModel();
      String[] fil = new String[1];
      for (int i = 0; i < criterios.size(); i++) {
        fil[0] = criterios.get(i).getSemestre();
        modelo.addRow(fil);
      }
      tblDatos.setModel(modelo);
    }
    JPanel panel = new JPanel();
    scrollPane.setRowHeaderView(panel);
    
    JComboBox cmbSemestre = new JComboBox();
    cmbSemestre.setModel(new DefaultComboBoxModel(new String[] {"5to semestre", "6to semestre", 
        "7mo semestre", "8vo semestre", "9vo semestre", "10mo semestre", 
        "Aplicaciones web", "Inteligencia artificial", "Sistemas m\u00F3viles y embebidos", 
        "Tecnolog\u00EDas de base de datos"}));
    
    JButton btnAgregar = new JButton("Agregar");
    btnAgregar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String semestre = (String) cmbSemestre.getSelectedItem();
        Criterio criterio = new Criterio();
        criterio.setSemestre(semestre);
        if (criterio.verifica(criterios)) {
          JOptionPane.showMessageDialog(null, "El semestre ya ha sido agregado :(");
        } else {
            criterios.add(criterio);
            String[] fila = new String[1];
            modelo = (DefaultTableModel) tblDatos.getModel();
            fila[0] = semestre;
            modelo.addRow(fila);
            tblDatos.setModel(modelo);
        }

      }
    });
    
    JButton btnEliminar = new JButton("Eliminar");
    btnEliminar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        int fila = tblDatos.getSelectedRow();
        if (fila >= 0 && fila < criterios.size()) {
          modelo = (DefaultTableModel) tblDatos.getModel();
          criterios.remove(fila);
          modelo.removeRow(fila);
          tblDatos.setModel(modelo);
        } else {
          JOptionPane.showMessageDialog(null, "Seleccione una fila :)");
        }
      }
    });
    panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
    panel.add(cmbSemestre);
    panel.add(btnAgregar);
    panel.add(btnEliminar);
    
    JPanel panelBotones = new JPanel();
    contentPane.add(panelBotones, BorderLayout.SOUTH);
    
    JButton btnEnviar = new JButton("Enviar");
    btnEnviar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        if (criterios.size() > 0) {
          criteriosImp.eliminarCriterios();
          for (int i = 0; i < criterios.size(); i++) {
              criteriosImp.insertarCriterios(criterios.get(i));
            }
            String cad = "Se registraron los siguientes criterios:\n ";
            for (int i = 0; i < criterios.size(); i++) {
              cad += criterios.get(i).getSemestre();
              cad += "\n";
            }
            JOptionPane.showMessageDialog(null, cad);
            criterios.clear();
            LoginProfesor login = new LoginProfesor(profesor);
            setVisible(false);
            login.setVisible(true);
        } else {
          JOptionPane.showMessageDialog(null, "No se puede enviar porque no hay registros :(");
        }
      }
    });
    panelBotones.add(btnEnviar);
    
    JButton btnRegresar = new JButton("Regresar");
    btnRegresar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        LoginProfesor login = new LoginProfesor(profesor);
        setVisible(false);
        login.setVisible(true);
      }
    });
    panelBotones.add(btnRegresar);
  }
  


}
