package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import basedatos.ProfesorDAO;
import basedatos.ProfesorImp;
import basedatos.UsuarioProfesorImp;
import modelo.Cuenta;
import modelo.Estudiante;
import modelo.Profesor;
import modelo.UsuarioProfesor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;

public class Bienvenida extends JFrame {

  private JPanel contentPane;
  static JTextField txtCorreoInstitucional;
  private static JPasswordField pwdPassword;
  private UsuarioProfesor usuarioProfesor;
  private Estudiante estudiante = new Estudiante();
  private Profesor profesor = new Profesor();
  private Cuenta usuarioEstudiante = new Cuenta();
  private EstudianteIMPA estudianteDao = new EstudianteIMPA();
  private ProfesorImp profesorImp = new ProfesorImp();
  private UsuarioProfesorImp usuarioProfesorDao = new UsuarioProfesorImp();

  /**
   * Launch the application.
   */
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel");
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
      | UnsupportedLookAndFeelException e1) {
      // TODO Auto-generated catch block
      e1.printStackTrace();
    }
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        try {
          Bienvenida frame = new Bienvenida();
          frame.setVisible(true);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
  }

  /**
   * Create the frame.
   */
  public Bienvenida() {
    setTitle("Bienvenida");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 476, 327);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JPanel panelSuperior = new JPanel();
    panelSuperior.setBorder(null);
    contentPane.add(panelSuperior, BorderLayout.NORTH);
    
    JLabel lblBienvenido = new JLabel("\u00A1\u00A1\u00A1Bienvenido!!!");
    lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
    panelSuperior.add(lblBienvenido);
    
    JPanel panelInferior = new JPanel();
    panelInferior.setBorder(null);
    contentPane.add(panelInferior, BorderLayout.SOUTH);
    panelInferior.setLayout(new BorderLayout(0, 0));
    
    JPanel panelBotones = new JPanel();
    panelBotones.setBorder(null);
    panelInferior.add(panelBotones, BorderLayout.EAST);
    
    JButton btnRegistrarProfesor = new JButton("Registrar Profesor");
    btnRegistrarProfesor.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        RegistroProfesor registro = new RegistroProfesor();
        setVisible(false);
        registro.setVisible(true);
      }
    });
    panelBotones.add(btnRegistrarProfesor);
    
    JButton btnRegistrarEstudiante = new JButton("Registrar Estudiante");
    btnRegistrarEstudiante.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Registro registro = new Registro();
        setVisible(false);
        registro.setVisible(true);
      }
    });
    panelBotones.add(btnRegistrarEstudiante);
    
    JPanel panelCentral = new JPanel();
    contentPane.add(panelCentral, BorderLayout.CENTER);
    panelCentral.setLayout(new GridLayout(5, 1, 0, 0));
    
    JPanel panelEtiqueta = new JPanel();
    panelEtiqueta.setBorder(null);
    FlowLayout fl_panelEtiqueta = (FlowLayout) panelEtiqueta.getLayout();
    panelCentral.add(panelEtiqueta);
    
    JLabel lblIniciarSesion = new JLabel("Iniciar Sesion");
    lblIniciarSesion.setHorizontalAlignment(SwingConstants.CENTER);
    panelEtiqueta.add(lblIniciarSesion);
    
    JPanel paneltxtIniciar = new JPanel();
    paneltxtIniciar.setBorder(null);
    panelCentral.add(paneltxtIniciar);
    
    JLabel lblCorreoInstitucional = new JLabel("Correo Institucional");
    paneltxtIniciar.add(lblCorreoInstitucional);
    
    txtCorreoInstitucional = new JTextField();
    txtCorreoInstitucional.setHorizontalAlignment(SwingConstants.CENTER);
    paneltxtIniciar.add(txtCorreoInstitucional);
    txtCorreoInstitucional.setColumns(10);
    
    JPanel panelPassword = new JPanel();
    panelPassword.setBorder(null);
    panelCentral.add(panelPassword);
    
    JLabel lblContrasea = new JLabel("Contrase\u00F1a");
    lblContrasea.setHorizontalAlignment(SwingConstants.CENTER);
    panelPassword.add(lblContrasea);
    
    JPanel panelPass = new JPanel();
    panelPass.setBorder(null);
    panelPassword.add(panelPass);
    
    pwdPassword = new JPasswordField();
    pwdPassword.setHorizontalAlignment(SwingConstants.CENTER);
    pwdPassword.setText("Contrase\u00F1a");
    panelPass.add(pwdPassword);
    
    JPanel panelTipo = new JPanel();
    panelTipo.setBorder(null);
    panelCentral.add(panelTipo);
    
    JLabel lblTipoDeUsuario = new JLabel("Tipo de Usuario");
    lblTipoDeUsuario.setHorizontalAlignment(SwingConstants.CENTER);
    panelTipo.add(lblTipoDeUsuario);
    
    JComboBox cmbTipoUsuario = new JComboBox();
    cmbTipoUsuario.setModel(new DefaultComboBoxModel(new String[] {"Estudiante", "Profesor"}));
    panelTipo.add(cmbTipoUsuario);
    
    JPanel panelBotonInicio = new JPanel();
    panelBotonInicio.setBorder(null);
    panelCentral.add(panelBotonInicio);
    
    JButton btnIniciarSesion = new JButton("Iniciar Sesion");
    btnIniciarSesion.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String tipo = (String) cmbTipoUsuario.getSelectedItem();   
        UsuarioProfesor usuarioProfesorH = null;
        Profesor profesorH = null;
        Estudiante estudianteH = null;
        Cuenta usuarioEstudianteH = null;
        //Alamacenamos las variables
        String correoInstitucional = txtCorreoInstitucional.getText();
        char[] cifrado = pwdPassword.getPassword();
        String password = String.valueOf(cifrado);
        if (correoInstitucional != null && password != null) {
            if (tipo.equals("Estudiante")) {
                usuarioEstudiante = new Cuenta();
                usuarioEstudiante.setCorreoInstitucional(correoInstitucional);
                usuarioEstudiante.setPassword(password);
                usuarioEstudianteH = estudianteDao.consultar(usuarioEstudiante);
                if (usuarioEstudianteH != null) {
                  estudiante.setMatricula(usuarioEstudianteH.getMatricula());
                  estudianteH = estudianteDao.consultarEstudiante(estudiante);
                  LoginEstudiante login = new LoginEstudiante(estudianteH);
                  setVisible(false);
                  login.setVisible(true);
                } else {
                  JOptionPane.showMessageDialog(null, "No se encontro el Estudiante :(");
                }
                
              } else {
                usuarioProfesor = new UsuarioProfesor();
                usuarioProfesor.setCorreoInstitucional(correoInstitucional);
                usuarioProfesor.setPassword(password);
                usuarioProfesorH = usuarioProfesorDao.consultarUsuario(usuarioProfesor);
                if (usuarioProfesorH != null) {
                  profesor.setNumTrabajador(usuarioProfesorH.getNumeroTrabajador());
                  profesorH = profesorImp.consultarProfesor(profesor);
                  LoginProfesor login = new LoginProfesor(profesorH);
                  setVisible(false);
                  login.setVisible(true);
                } else {
                  JOptionPane.showMessageDialog(null, "No se encontro al Profesor :(");
                }
                
              }
              
        } else {
          JOptionPane.showMessageDialog(null, "EL Correo o Contrasela vacios :(");
        }
        
        
      }
    });
    panelBotonInicio.add(btnIniciarSesion);
  }
}
