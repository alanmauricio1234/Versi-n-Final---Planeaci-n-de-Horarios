package control;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.ProfesorImp;
import modelo.Profesor;
import modelo.UsuarioProfesor;
import modelo.Validacion;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class RegistroProfesor extends JFrame {

  private JPanel contentPane;
  private Validacion validacion = new Validacion();
  private JTextField txtNombre;
  private JTextField txtApellidoP;
  private JTextField txtApellidoM;
  private JTextField txtNumTrabajador;
  private JTextField txtCorreoInstitucional;
  private JTextField txtCorreoPersonal;
  private JTextField txtCubiculo;
  private JTextField txtNumeroCelular;
  private JTextField txtExtension;
  private JPasswordField txtPassword;



  /**
   * Create the frame.
   */
  public RegistroProfesor() {
    setTitle("Registrar Un Profesor");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 569, 375);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JPanel panelSuperior = new JPanel();
    contentPane.add(panelSuperior, BorderLayout.NORTH);
    
    JLabel lblIngresaLoQue = new JLabel("Ingresa lo que se te indica");
    panelSuperior.add(lblIngresaLoQue);
    
    JPanel panelInferior = new JPanel();
    panelInferior.setBorder(null);
    contentPane.add(panelInferior, BorderLayout.SOUTH);
    panelInferior.setLayout(new BorderLayout(0, 0));
    
    JPanel panelBotones = new JPanel();
    panelBotones.setBorder(null);
    panelInferior.add(panelBotones, BorderLayout.EAST);
    
    JLabel lblMensaje = new JLabel("");
    panelInferior.add(lblMensaje, BorderLayout.WEST);
    
    JComboBox cmbAcademia = new JComboBox();
    cmbAcademia.setModel(new DefaultComboBoxModel(new String[] {"Informatica"}));
    
    JComboBox cmbPlantel = new JComboBox();
    cmbPlantel.setModel(new DefaultComboBoxModel(new String[] {"San Lorenzo Tezonco", 
        "Casa Libertad", "Centro Historico", "Cuatepec", "Del Valle"}));
    
    JComboBox cmbColegio = new JComboBox();
    cmbColegio.setModel(new DefaultComboBoxModel(new String[] {"Ciencia y Tecnologia"}));
    
    JButton btnRegistarse = new JButton("Registarse");
    btnRegistarse.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Profesor profesor = null;
        UsuarioProfesor usuario = null;
        ProfesorImp profesorDao = null;
        boolean verificar = false;
        String nombre = txtNombre.getText();
        String apellidoP = txtApellidoP.getText();
        String apellidoM = txtApellidoM.getText();
        String numeroTrabajador = txtNumTrabajador.getText();
        String correoInstitucional = txtCorreoInstitucional.getText();
        String correoPersonal = txtCorreoPersonal.getText();
        String colegio = (String) cmbColegio.getSelectedItem();
        String plantel = (String) cmbPlantel.getSelectedItem();
        String academia = (String) cmbAcademia.getSelectedItem();
        String cubiculo = txtCubiculo.getText();
        String numeroCelular = txtNumeroCelular.getText();
        String extension = txtExtension.getText();
        String password = "";
        char[] contrasena = txtPassword.getPassword();
        for (int i = 0; i < contrasena.length; i++) {
          password += contrasena[i];
        }
        verificar = validacion.validarCorreoInsProfesor(correoInstitucional) 
                && validacion.validarCorreoPersonal(correoPersonal) 
                && validacion.validarNumTel(numeroCelular)
                && nombre.length() > 0 && nombre.length() <= 30
                && apellidoP.length() > 0 && apellidoP.length() <= 20
                && apellidoM.length() > 0 && apellidoM.length() <= 20
                && cubiculo.length() > 0 && cubiculo.length() <= 5 
                && validacion.validarExtension(extension)
                && password.length() > 0
                && validacion.validarNumTrabajador(numeroTrabajador);
        if (verificar) {
          //Creamos el objeto que inserta en la base de datos
          profesorDao = new ProfesorImp();
          //Creamos el objeto profesor
          profesor = new Profesor();
          profesor.setNumTrabajador(numeroTrabajador);
          profesor.setNombre(nombre);
          profesor.setApellidoP(apellidoP);
          profesor.setApellidoM(apellidoM);
          profesor.setCorreoInstitucional(correoInstitucional);
          profesor.setCorreoPersonal(correoPersonal);
          profesor.setColegioAdscripcion(colegio);
          profesor.setPlantelAdscripcion(plantel);
          profesor.setAcademia(academia);
          profesor.setCubiculo(cubiculo);
          profesor.setNumCelular(numeroCelular);
          profesor.setExtension(extension);
          //Creamos al usuario y le asigamos los datos
          usuario = new UsuarioProfesor();
          usuario.setCorreoInstitucional(correoInstitucional);
          usuario.setNumeroTrabajador(numeroTrabajador);
          usuario.setPassword(password);
          
          //Insertamos los objetos en la base de datos
          profesorDao.insertarTransaccion(profesor, usuario);
          //Cambiamos de ventana
          Bienvenida bienvenida = new Bienvenida();
          setVisible(false);
          bienvenida.setVisible(true);
        } else {
          lblMensaje.setText("Los campos en rojo estan incorrectos :(");
          if (validacion.validarCorreoInsProfesor(correoInstitucional) == false) {
            txtCorreoInstitucional.setBackground(Color.red);
          } else {
            txtCorreoInstitucional.setBackground(Color.green);
          }
          if (validacion.validarNumTel(numeroCelular) == false) {
            txtNumeroCelular.setBackground(Color.red);
          } else {
            txtNumeroCelular.setBackground(Color.green);
          }
          if (validacion.validarCorreoPersonal(correoPersonal) == false) {
            txtCorreoPersonal.setBackground(Color.red);
          } else {
            txtCorreoPersonal.setBackground(Color.green);
          }
          if (nombre.length() == 0) {
            txtNombre.setBackground(Color.red);
          } else {
            txtNombre.setBackground(Color.green);
          }
          if (apellidoP.length() == 0) {
            txtApellidoP.setBackground(Color.red);
          } else {
            txtApellidoP.setBackground(Color.green);
          }
          if (apellidoM.length() == 0) {
            txtApellidoM.setBackground(Color.red);
          } else {
            txtApellidoM.setBackground(Color.green);
          }
          if (cubiculo.length() == 0) {
            txtCubiculo.setBackground(Color.red);
          } else {
            txtCubiculo.setBackground(Color.green);
          }
          if (validacion.validarExtension(extension) == false) {
            txtExtension.setBackground(Color.red);
          } else {
            txtExtension.setBackground(Color.green);
          }
          if (validacion.validarNumTrabajador(numeroTrabajador) == false) {
            txtNumTrabajador.setBackground(Color.red);
          } else {
            txtNumTrabajador.setBackground(Color.green);
          }
          if (password.length() == 0) {
            txtPassword.setBackground(Color.red);
          } else {
            txtPassword.setBackground(Color.green);
          }
        }
        
        
      }
    });
    panelBotones.add(btnRegistarse);
    
    JButton btnRegresar = new JButton("Regresar");
    btnRegresar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Bienvenida bienvenida = new Bienvenida();
        setVisible(false);
        bienvenida.setVisible(true);
      }
    });
    panelBotones.add(btnRegresar);
    
    JPanel panelCentral = new JPanel();
    contentPane.add(panelCentral, BorderLayout.CENTER);
    panelCentral.setLayout(new BorderLayout(0, 0));
    
    JPanel panelRegistro = new JPanel();
    panelCentral.add(panelRegistro, BorderLayout.CENTER);
    panelRegistro.setLayout(new GridLayout(13, 2, 0, 0));
    
    JLabel lblNombre = new JLabel("Nombre:");
    panelRegistro.add(lblNombre);
    
    txtNombre = new JTextField();
    txtNombre.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (Character.isDigit(c)) {
          e.consume();
        }
      }
    });
    panelRegistro.add(txtNombre);
    txtNombre.setColumns(10);
    
    JLabel lblApellidoPaterno = new JLabel("Apellido Paterno");
    panelRegistro.add(lblApellidoPaterno);
    
    txtApellidoP = new JTextField();
    txtApellidoP.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
          char c = e.getKeyChar();
          if (Character.isDigit(c)) {
            e.consume();
          }
      }
    });
    panelRegistro.add(txtApellidoP);
    txtApellidoP.setColumns(10);
    
    JLabel lblApellidoMaterno = new JLabel("Apellido Materno");
    panelRegistro.add(lblApellidoMaterno);
    
    txtApellidoM = new JTextField();
    txtApellidoM.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
          char c = e.getKeyChar();
          if (Character.isDigit(c)) {
            e.consume();
          }
      }
    });
    panelRegistro.add(txtApellidoM);
    txtApellidoM.setColumns(10);
    
    JLabel lblNumeroDeTrabajador = new JLabel("Numero de Trabajador");
    panelRegistro.add(lblNumeroDeTrabajador);
    
    txtNumTrabajador = new JTextField();
    txtNumTrabajador.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
          char c = e.getKeyChar();
          if (c < '0' || c > '9') {
            e.consume();
          }
      }
    });
    panelRegistro.add(txtNumTrabajador);
    txtNumTrabajador.setColumns(10);
    
    JLabel lblCorreoInstitucional = new JLabel("Correo Institucional");
    panelRegistro.add(lblCorreoInstitucional);
    
    txtCorreoInstitucional = new JTextField();
    panelRegistro.add(txtCorreoInstitucional);
    txtCorreoInstitucional.setColumns(10);
    
    JLabel lblCorreoPersonal = new JLabel("Correo Personal");
    panelRegistro.add(lblCorreoPersonal);
    
    txtCorreoPersonal = new JTextField();
    panelRegistro.add(txtCorreoPersonal);
    txtCorreoPersonal.setColumns(10);
    
    JLabel lblColegio = new JLabel("Colegio");
    panelRegistro.add(lblColegio);
    

    panelRegistro.add(cmbColegio);
    
    JLabel lblPlantel = new JLabel("Plantel");
    panelRegistro.add(lblPlantel);
    

    panelRegistro.add(cmbPlantel);
    
    JLabel lblAcademia = new JLabel("Academia");
    panelRegistro.add(lblAcademia);
    

    panelRegistro.add(cmbAcademia);
    
    JLabel lblCubiculo = new JLabel("Cubiculo");
    panelRegistro.add(lblCubiculo);
    
    txtCubiculo = new JTextField();
    panelRegistro.add(txtCubiculo);
    txtCubiculo.setColumns(10);
    
    JLabel lblNumeroDeCelular = new JLabel("Numero de Celular");
    panelRegistro.add(lblNumeroDeCelular);
    
    txtNumeroCelular = new JTextField();
    txtNumeroCelular.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
          char c = e.getKeyChar();
          if (c < '0' || c > '9') {
            e.consume();
          }
      }
    });
    panelRegistro.add(txtNumeroCelular);
    txtNumeroCelular.setColumns(10);
    
    JLabel lblExtension = new JLabel("Extension");
    panelRegistro.add(lblExtension);
    
    txtExtension = new JTextField();
    txtExtension.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
          char c = e.getKeyChar();
          if (c < '0' || c > '9') {
            e.consume();
          }
      }
    });
    panelRegistro.add(txtExtension);
    txtExtension.setColumns(10);
    
    JLabel lblContrasea = new JLabel("Contrase\u00F1a");
    panelRegistro.add(lblContrasea);
    
    txtPassword = new JPasswordField();
    panelRegistro.add(txtPassword);
}

}
