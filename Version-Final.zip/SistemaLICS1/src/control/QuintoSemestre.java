package control;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class QuintoSemestre extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	EstudianteIMPA invocar = new EstudianteIMPA();
	private String semestre;
    private String matricula;
	private String cve_materia;
	private String status;

	private JPanel contentPane;
    public static JTextField reciboNombre;
    public static JTextField reciboContrasena;
    public static JTextField AnalisisReq;
    public static JTextField AnalisisAlgo;
    public static JTextField TeoriaCompu;
    public static JTextField BasesdeDatos;
    public static JTextField Construccion;
    public static  JTextField txtConstruccionYEvo;
  
	Historiales acceder = new Historiales();


	/**
	 * Create the frame.
	 */
	public QuintoSemestre(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 590);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		reciboNombre = new JTextField(estudiante.getNombre());
		reciboNombre.setEditable(false);
		reciboNombre.setBounds(98, 11, 200, 20);
		contentPane.add(reciboNombre);
		reciboNombre.setColumns(10);
		
		reciboContrasena = new JTextField(estudiante.getMatricula());
		reciboContrasena.setEditable(false);
		reciboContrasena.setBounds(98, 53, 200, 20);
		contentPane.add(reciboContrasena);
		reciboContrasena.setColumns(10);
		
		AnalisisReq = new JTextField();
		AnalisisReq.setText("Analisis de Requisitos");
		AnalisisReq.setBounds(10, 280, 178, 20);
		contentPane.add(AnalisisReq);
		AnalisisReq.setBackground(Color.red);
		AnalisisReq.setColumns(10);
		
		JList list = new JList();
		list.setBounds(226, 150, 43, -44);
		contentPane.add(list);
		
		JComboBox SemestreANR = new JComboBox();
		SemestreANR.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreANR.setBounds(441, 279, 89, 22);
		contentPane.add(SemestreANR);
		SemestreANR.setVisible(false);
		
	    JComboBox Colores = new JComboBox();
		Colores.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores.getSelectedIndex();
		        if( indice == 1){
		        	AnalisisReq.setBackground(Color.green);
		        	SemestreANR.setVisible(true);
		        }else{
		            if(indice == 2){
		            	AnalisisReq.setBackground(Color.yellow);
		            	SemestreANR.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		AnalisisReq.setBackground(Color.red);
		            		SemestreANR.setVisible(false);
		            	}
		            }
		        }		        
			}
		});
		Colores.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores.setBounds(215, 280, 150, 20);
		contentPane.add(Colores);
		
		JLabel lblAlumno = new JLabel("ALUMNO");
		lblAlumno.setBounds(10, 14, 57, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblMatricula = new JLabel("MATRICULA");
		lblMatricula.setBounds(10, 56, 77, 14);
		contentPane.add(lblMatricula);
		
		JLabel lblMarcaConVerde = new JLabel("Marca con Verde las materias que has certificado");
		lblMarcaConVerde.setBounds(10, 81, 299, 14);
		contentPane.add(lblMarcaConVerde);
		
		JLabel lblMarcaConAmarillo = new JLabel("Marca con Amarillo las materias que estas cursando");
		lblMarcaConAmarillo.setBounds(10, 106, 310, 14);
		contentPane.add(lblMarcaConAmarillo);
		
		AnalisisAlgo = new JTextField();
		AnalisisAlgo.setText("Analisis de Algoritmos");
		AnalisisAlgo.setColumns(10);
		AnalisisAlgo.setBounds(10, 329, 178, 20);
		AnalisisAlgo.setBackground(Color.red);
		contentPane.add(AnalisisAlgo);
		
		JComboBox SemestreALG = new JComboBox();
		SemestreALG.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreALG.setBounds(441, 328, 89, 22);
		contentPane.add(SemestreALG);
		SemestreALG.setVisible(false);
		
		final JComboBox Colores2 = new JComboBox();
		Colores2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores2.getSelectedIndex();
		        if( indice == 1){
		        	AnalisisAlgo.setBackground(Color.green);
		        	SemestreALG.setVisible(true);
		        }else{
		            if(indice == 2){
		            	AnalisisAlgo.setBackground(Color.yellow);
		                SemestreALG.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		AnalisisAlgo.setBackground(Color.red);
		            		SemestreALG.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores2.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores2.setBounds(215, 329, 150, 20);
		contentPane.add(Colores2);
		
		JComboBox SemestreTYC = new JComboBox();
		SemestreTYC.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreTYC.setBounds(441, 373, 89, 22);
		contentPane.add(SemestreTYC);
		SemestreTYC.setVisible(false);
		
		final JComboBox Colores3 = new JComboBox();
		Colores3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores3.getSelectedIndex();
		        if( indice == 1){
		        	TeoriaCompu.setBackground(Color.green);
		        	SemestreTYC.setVisible(true);
		        }else{
		            if(indice == 2){
		            	TeoriaCompu.setBackground(Color.yellow);
		                SemestreTYC.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		TeoriaCompu.setBackground(Color.red);
		            		SemestreTYC.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores3.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores3.setBounds(215, 374, 150, 20);
		contentPane.add(Colores3);
		
		TeoriaCompu = new JTextField();
		TeoriaCompu.setText("Teoria de la Computacion");
		TeoriaCompu.setBounds(10, 374, 178, 20);
		contentPane.add(TeoriaCompu);
		TeoriaCompu.setBackground(Color.red);
		TeoriaCompu.setColumns(10);
		
		JComboBox SemestreBDD = new JComboBox();
		SemestreBDD.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreBDD.setBounds(441, 422, 89, 22);
		contentPane.add(SemestreBDD);
		SemestreBDD.setVisible(false);
		
		BasesdeDatos = new JTextField();
		BasesdeDatos.setBounds(10, 423, 178, 20);
		BasesdeDatos.setText("Bases de Datos");
		contentPane.add(BasesdeDatos);
		BasesdeDatos.setBackground(Color.red);
		BasesdeDatos.setColumns(10);
		
		
		final JComboBox Colores4 = new JComboBox();
		Colores4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores4.getSelectedIndex();
		        if( indice == 1){
		        	BasesdeDatos.setBackground(Color.green);
		        	SemestreBDD.setVisible(true);
		        }else{
		            if(indice == 2){
		            	BasesdeDatos.setBackground(Color.yellow);
		                SemestreBDD.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		BasesdeDatos.setBackground(Color.red);
		            		SemestreBDD.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores4.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores4.setBounds(215, 423, 150, 20);
		contentPane.add(Colores4);
		
		txtConstruccionYEvo = new JTextField();
		txtConstruccionYEvo.setText("Construccion y Evolucion de S.");
		txtConstruccionYEvo.setColumns(10);
		txtConstruccionYEvo.setBackground(Color.RED);
		txtConstruccionYEvo.setBounds(10, 469, 178, 20);
		contentPane.add(txtConstruccionYEvo);
		
		JComboBox SemestreEVO = new JComboBox();
		SemestreEVO.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreEVO.setBounds(441, 468, 89, 22);
		contentPane.add(SemestreEVO);
		SemestreEVO.setVisible(false);
		
		JComboBox Colores5 = new JComboBox();
		Colores5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores5.getSelectedIndex();
		        if( indice == 1){
		        	txtConstruccionYEvo.setBackground(Color.green);
		        	SemestreEVO.setVisible(true);
		        }else{
		            if(indice == 2){
		            	txtConstruccionYEvo.setBackground(Color.yellow);
		                SemestreEVO.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		txtConstruccionYEvo.setBackground(Color.red);
		            		SemestreEVO.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores5.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores5.setBounds(215, 469, 150, 20);
		contentPane.add(Colores5);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for(Historiales temp:acceder.getLista()) {
						System.out.println(""+temp.getCve_materia());
					}
					if(Colores.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-08";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						}else {
						if(SemestreANR.getSelectedIndex() == 0 || SemestreANR.getSelectedIndex() == 1 || SemestreANR.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-08";
			            	
			            	if( Colores.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreANR.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores2.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-04";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
		            		JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
		            	}
						}else {
						if( SemestreALG.getSelectedIndex()== 0 || SemestreALG.getSelectedIndex() == 1 || SemestreTYC.getSelectedIndex() == 2) {	
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-04";
			            	
			            	if( Colores2.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreALG.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores2.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores3.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-05";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo pedes estar cursando 7 materias");
						}
						}else {
						if( SemestreTYC.getSelectedIndex() == 0 || SemestreTYC.getSelectedIndex() == 1 || SemestreTYC.getSelectedIndex() == 2) {	
							String semestre = null;
							
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-05";
			            	
			            	if( Colores3.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreTYC.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores4.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-07";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						}else {
						if( SemestreBDD.getSelectedIndex( ) == 0 || SemestreBDD.getSelectedIndex() == 1 || SemestreBDD.getSelectedIndex() == 2) {	
							
							String semestre = null;
		
								matricula = Registro.textMatricula.getText();
				            	cve_materia="1-CT-IS-07";
				            	
				            	if( Colores4.getSelectedIndex() == 1 ) {
									semestre = (String)SemestreBDD.getSelectedItem();
									status="certificado";
				            	}else {
				            		if( Colores4.getSelectedIndex() == 0 ) {
									semestre = "2019-II";
								    status = "No certificado";
				            		}
								}
				            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
				            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores5.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-06";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						}else {
						if(SemestreEVO.getSelectedIndex() == 0 || SemestreEVO.getSelectedIndex() == 1 || SemestreEVO.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-06";
			            	
			            	if( Colores5.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreEVO.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores5.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					JOptionPane.showMessageDialog(null, "Registro exitoso");
					OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
					visible.setVisible(true);
					setVisible(false);
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Registro fallido");
				}
			}
		});
		btnRegistrar.setBounds(10, 517, 139, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblMateriasQueNo = new JLabel("Materias que NO has cursado o NO has pasado dejalas en ROJO");
		lblMateriasQueNo.setFont(new Font("Stencil", Font.PLAIN, 12));
		lblMateriasQueNo.setBounds(10, 131, 424, 22);
		contentPane.add(lblMateriasQueNo);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnRegresar.setBounds(426, 517, 104, 23);
		contentPane.add(btnRegresar);
		
		JLabel lblSiNoHas = new JLabel("Si no has CURSADO o CERTIFICADO ninguna solo OPRIME registrar");
		lblSiNoHas.setFont(new Font("Stencil", Font.PLAIN, 16));
		lblSiNoHas.setBounds(7, 164, 558, 36);
		contentPane.add(lblSiNoHas);
		
		JLabel lblEnCasoDe = new JLabel("En caso de optimir certificado");
		lblEnCasoDe.setBounds(426, 199, 167, 14);
		contentPane.add(lblEnCasoDe);
		
		JLabel lblInicaEnQue = new JLabel("indica en que semestre\r\n");
		lblInicaEnQue.setBounds(426, 224, 167, 14);
		contentPane.add(lblInicaEnQue);
	}
}