package control;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class SextoSemestre extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	EstudianteIMPA invocar = new EstudianteIMPA();
	private String semestre;
    private String matricula;
	private String cve_materia;
	private String status;

	private JPanel contentPane;
    public static JTextField reciboNombre;
    public static JTextField reciboContrasena;
    public static JTextField ProgramacionWeb;
    public static JTextField SistemasOperativos;
    public static JTextField Calidad;
    public static JTextField Modelamiento;
    public static JTextField Construccion;
    public static  JTextField Sistemas;

	/**
	 * Create the frame.
	 */
	public SextoSemestre(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		reciboNombre = new JTextField(estudiante.getNombre());
		reciboNombre.setEditable(false);
		reciboNombre.setBounds(98, 11, 200, 20);
		contentPane.add(reciboNombre);
		reciboNombre.setColumns(10);
		
		reciboContrasena = new JTextField(estudiante.getMatricula());
		reciboContrasena.setEditable(false);
		reciboContrasena.setBounds(98, 53, 200, 20);
		contentPane.add(reciboContrasena);
		reciboContrasena.setColumns(10);
		
		ProgramacionWeb = new JTextField();
		ProgramacionWeb.setText("Programacion WEB");
		ProgramacionWeb.setBounds(10, 261, 178, 20);
		contentPane.add(ProgramacionWeb);
		ProgramacionWeb.setBackground(Color.red);
		ProgramacionWeb.setColumns(10);
		
		JList list = new JList();
		list.setBounds(226, 150, 43, -44);
		contentPane.add(list);
		
		JComboBox SemestreWEB = new JComboBox();
		SemestreWEB.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreWEB.setBounds(441, 260, 89, 22);
		contentPane.add(SemestreWEB);
		SemestreWEB.setVisible(false);
		
	    JComboBox Colores = new JComboBox();
		Colores.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores.getSelectedIndex();
		        if( indice == 1){
		        	ProgramacionWeb.setBackground(Color.green);
		        	SemestreWEB.setVisible(true);
		        }else{
		            if(indice == 2){
		            	ProgramacionWeb.setBackground(Color.yellow);
		            	SemestreWEB.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		ProgramacionWeb.setBackground(Color.red);
		            		SemestreWEB.setVisible(false);
		            	}
		            }
		        }		        
			}
		});
		Colores.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores.setBounds(215, 261, 150, 20);
		contentPane.add(Colores);
		
		JLabel lblAlumno = new JLabel("ALUMNO");
		lblAlumno.setBounds(10, 14, 57, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblMatricula = new JLabel("MATRICULA");
		lblMatricula.setBounds(10, 56, 77, 14);
		contentPane.add(lblMatricula);
		
		JLabel lblMarcaConVerde = new JLabel("Marca con Verde las materias que has certificado");
		lblMarcaConVerde.setBounds(10, 81, 299, 14);
		contentPane.add(lblMarcaConVerde);
		
		JLabel lblMarcaConAmarillo = new JLabel("Marca con Amarillo las materias que estas cursando");
		lblMarcaConAmarillo.setBounds(10, 106, 310, 14);
		contentPane.add(lblMarcaConAmarillo);
		
		SistemasOperativos = new JTextField();
		SistemasOperativos.setText("Sistemas Operativos");
		SistemasOperativos.setColumns(10);
		SistemasOperativos.setBounds(10, 310, 178, 20);
		SistemasOperativos.setBackground(Color.red);
		contentPane.add(SistemasOperativos);
		
		JComboBox SemestreOPE = new JComboBox();
		SemestreOPE.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreOPE.setBounds(441, 309, 89, 22);
		contentPane.add(SemestreOPE);
		SemestreOPE.setVisible(false);
		
		final JComboBox Colores2 = new JComboBox();
		Colores2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores2.getSelectedIndex();
		        if( indice == 1){
		        	SistemasOperativos.setBackground(Color.green);
		        	SemestreOPE.setVisible(true);
		        }else{
		            if(indice == 2){
		            	SistemasOperativos.setBackground(Color.yellow);
		                SemestreOPE.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		SistemasOperativos.setBackground(Color.red);
		            		SemestreOPE.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores2.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores2.setBounds(215, 310, 150, 20);
		contentPane.add(Colores2);
		
		JComboBox SemestreCAL = new JComboBox();
		SemestreCAL.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreCAL.setBounds(441, 362, 89, 22);
		contentPane.add(SemestreCAL);
		SemestreCAL.setVisible(false);
		
		final JComboBox Colores3 = new JComboBox();
		Colores3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores3.getSelectedIndex();
		        if( indice == 1){
		        	Calidad.setBackground(Color.green);
		        	SemestreCAL.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Calidad.setBackground(Color.yellow);
		                SemestreCAL.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Calidad.setBackground(Color.red);
		            		SemestreCAL.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores3.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores3.setBounds(215, 363, 150, 20);
		contentPane.add(Colores3);
		
		Calidad = new JTextField();
		Calidad.setText("Aseguramiento de la Calidad");
		Calidad.setBounds(10, 363, 178, 20);
		contentPane.add(Calidad);
		Calidad.setBackground(Color.red);
		Calidad.setColumns(10);
		
		JComboBox SemestreMOD = new JComboBox();
		SemestreMOD.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreMOD.setBounds(441, 412, 89, 22);
		contentPane.add(SemestreMOD);
		SemestreMOD.setVisible(false);
		
		Modelamiento = new JTextField();
		Modelamiento.setBounds(10, 413, 178, 20);
		Modelamiento.setText("Analisis y Modelamiento");
		contentPane.add(Modelamiento);
		Modelamiento.setBackground(Color.red);
		Modelamiento.setColumns(10);
		
		
		final JComboBox Colores4 = new JComboBox();
		Colores4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores4.getSelectedIndex();
		        if( indice == 1){
		        	Modelamiento.setBackground(Color.green);
		        	SemestreMOD.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Modelamiento.setBackground(Color.yellow);
		                SemestreMOD.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Modelamiento.setBackground(Color.red);
		            		SemestreMOD.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores4.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores4.setBounds(215, 413, 150, 20);
		contentPane.add(Colores4);
		
		Sistemas = new JTextField();
		Sistemas.setText("Programacion de Sistemas");
		Sistemas.setColumns(10);
		Sistemas.setBackground(Color.RED);
		Sistemas.setBounds(10, 468, 178, 20);
		contentPane.add(Sistemas);
		
		JComboBox SemestreSIS = new JComboBox();
		SemestreSIS.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreSIS.setBounds(441, 467, 89, 22);
		contentPane.add(SemestreSIS);
		SemestreSIS.setVisible(false);
		
		JComboBox Colores5 = new JComboBox();
		Colores5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores5.getSelectedIndex();
		        if( indice == 1){
		        	Sistemas.setBackground(Color.green);
		        	SemestreSIS.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Sistemas.setBackground(Color.yellow);
		                SemestreSIS.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Sistemas.setBackground(Color.red);
		            		SemestreSIS.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores5.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores5.setBounds(215, 468, 150, 20);
		contentPane.add(Colores5);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(Colores.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-09";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						
					}else {
						if(SemestreWEB.getSelectedIndex() == 0 || SemestreWEB.getSelectedIndex() == 1 || SemestreWEB.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-09";
			            	
			            	if( Colores.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreWEB.getSelectedItem();
								status="certificado";
			            	}else {
								if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
								}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores2.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-10";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreOPE.getSelectedIndex()== 0 || SemestreOPE.getSelectedIndex() == 1 || SemestreCAL.getSelectedIndex() == 2) {	
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-10";
			            	
			            	if( Colores2.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreOPE.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores2.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores3.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-11";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						}else {
						if( SemestreCAL.getSelectedIndex() == 0 || SemestreCAL.getSelectedIndex() == 1 || SemestreCAL.getSelectedIndex() == 2) {	
							String semestre = null;
							
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-11";
			            	
			            	if( Colores3.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreCAL.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores4.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-12";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						}else {
						if( SemestreMOD.getSelectedIndex( ) == 0 || SemestreMOD.getSelectedIndex() == 1 || SemestreMOD.getSelectedIndex() == 2) {	
							
							String semestre = null;
		
								matricula = Registro.textMatricula.getText();
				            	cve_materia="1-CT-IS-12";
				            	
				            	if( Colores4.getSelectedIndex() == 1 ) {
									semestre = (String)SemestreMOD.getSelectedItem();
									status="certificado";
				            	}else {
									if( Colores4.getSelectedIndex() == 0 ) {
									semestre = "2019-II";
								    status = "No certificado";
									}
								}
				            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
				            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores5.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-13";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
						}else {
						if(SemestreSIS.getSelectedIndex() == 0 || SemestreSIS.getSelectedIndex() == 1 || SemestreSIS.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-13";
			            	
			            	if( Colores5.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreSIS.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores5.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					JOptionPane.showMessageDialog(null, "Registro exitoso");
					OpcionHistorial visible = new OpcionHistorial(estudiante,historial);
					visible.setVisible(true);
					setVisible(false);
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Registro fallido");
				}
			}
		});
		btnRegistrar.setBounds(10, 508, 139, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblMateriasQueNo = new JLabel("Materias que NO has cursado o NO has pasado dejalas en ROJO");
		lblMateriasQueNo.setFont(new Font("Stencil", Font.PLAIN, 12));
		lblMateriasQueNo.setBounds(10, 131, 424, 22);
		contentPane.add(lblMateriasQueNo);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionHistorial visible = new OpcionHistorial(estudiante,historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnRegresar.setBounds(426, 508, 104, 23);
		contentPane.add(btnRegresar);
		
		JLabel lblEnCasoDe = new JLabel("En caso de optimir certificado");
		lblEnCasoDe.setBounds(426, 199, 167, 14);
		contentPane.add(lblEnCasoDe);
		
		JLabel lblInicaEnQue = new JLabel("indica en que semestre\r\n");
		lblInicaEnQue.setBounds(426, 224, 167, 14);
		contentPane.add(lblInicaEnQue);
		
		JLabel lblSiNoHas = new JLabel("Si no has CURSADO o CERTIFICADO ninguna solo OPRIME registrar");
		lblSiNoHas.setFont(new Font("Stencil", Font.PLAIN, 16));
		lblSiNoHas.setBounds(7, 164, 558, 36);
		contentPane.add(lblSiNoHas);
		
	}
}