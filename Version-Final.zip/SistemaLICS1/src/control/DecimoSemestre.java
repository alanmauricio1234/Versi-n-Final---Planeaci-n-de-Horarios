package control;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class DecimoSemestre extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	EstudianteIMPA invocar = new EstudianteIMPA();
	private String semestre;
    private String matricula;
	private String cve_materia;
	private String status;

	private JPanel contentPane;
    public static JTextField reciboNombre;
    public static JTextField reciboContrasena;
    public static JTextField Experimentos;
    public static JTextField Administracion2;
    public static JTextField Gestion;
    public static JTextField Construccion;

	/**
	 * Create the frame.
	 */
	public DecimoSemestre(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 506);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		reciboNombre = new JTextField(estudiante.getNombre());
		reciboNombre.setEditable(false);
		reciboNombre.setBounds(98, 11, 200, 20);
		contentPane.add(reciboNombre);
		reciboNombre.setColumns(10);
		
		reciboContrasena = new JTextField(estudiante.getMatricula());
		reciboContrasena.setEditable(false);
		reciboContrasena.setBounds(98, 53, 200, 20);
		contentPane.add(reciboContrasena);
		reciboContrasena.setColumns(10);
		
		Experimentos = new JTextField();
		Experimentos.setText("Dise\u00F1o de Experimentos");
		Experimentos.setBounds(10, 261, 178, 20);
		contentPane.add(Experimentos);
		Experimentos.setBackground(Color.red);
		Experimentos.setColumns(10);
		
		JList list = new JList();
		list.setBounds(226, 150, 43, -44);
		contentPane.add(list);
		
		JComboBox SemestreEXP = new JComboBox();
		SemestreEXP.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreEXP.setBounds(441, 260, 89, 22);
		contentPane.add(SemestreEXP);
		SemestreEXP.setVisible(false);
		
	    JComboBox Colores = new JComboBox();
		Colores.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores.getSelectedIndex();
		        if( indice == 1){
		        	Experimentos.setBackground(Color.green);
		        	SemestreEXP.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Experimentos.setBackground(Color.yellow);
		            	SemestreEXP.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Experimentos.setBackground(Color.red);
		            		SemestreEXP.setVisible(false);
		            	}
		            }
		        }		        
			}
		});
		Colores.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores.setBounds(215, 261, 150, 20);
		contentPane.add(Colores);
		
		JLabel lblAlumno = new JLabel("ALUMNO");
		lblAlumno.setBounds(10, 14, 57, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblMatricula = new JLabel("MATRICULA");
		lblMatricula.setBounds(10, 56, 77, 14);
		contentPane.add(lblMatricula);
		
		JLabel lblMarcaConVerde = new JLabel("Marca con Verde las materias que has certificado");
		lblMarcaConVerde.setBounds(10, 81, 299, 14);
		contentPane.add(lblMarcaConVerde);
		
		JLabel lblMarcaConAmarillo = new JLabel("Marca con Amarillo las materias que estas cursando");
		lblMarcaConAmarillo.setBounds(10, 106, 310, 14);
		contentPane.add(lblMarcaConAmarillo);
		
		Administracion2 = new JTextField();
		Administracion2.setText("Administracion de Proyectos II");
		Administracion2.setColumns(10);
		Administracion2.setBounds(10, 310, 178, 20);
		Administracion2.setBackground(Color.red);
		contentPane.add(Administracion2);
		
		JComboBox SemestreADMPII = new JComboBox();
		SemestreADMPII.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreADMPII.setBounds(441, 309, 89, 22);
		contentPane.add(SemestreADMPII);
		SemestreADMPII.setVisible(false);
		
		final JComboBox Colores2 = new JComboBox();
		Colores2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores2.getSelectedIndex();
		        if( indice == 1){
		        	Administracion2.setBackground(Color.green);
		        	SemestreADMPII.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Administracion2.setBackground(Color.yellow);
		                SemestreADMPII.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Administracion2.setBackground(Color.red);
		            		SemestreADMPII.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores2.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores2.setBounds(215, 310, 150, 20);
		contentPane.add(Colores2);
		
		JComboBox SemestreGETEC = new JComboBox();
		SemestreGETEC.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreGETEC.setBounds(441, 361, 89, 22);
		contentPane.add(SemestreGETEC);
		SemestreGETEC.setVisible(false);
		
		final JComboBox Colores3 = new JComboBox();
		Colores3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores3.getSelectedIndex();
		        if( indice == 1){
		        	Gestion.setBackground(Color.green);
		        	SemestreGETEC.setVisible(true);
		        }else{
		            if(indice == 2){
		            	Gestion.setBackground(Color.yellow);
		                SemestreGETEC.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		Gestion.setBackground(Color.red);
		            		SemestreGETEC.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores3.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores3.setBounds(215, 362, 150, 20);
		contentPane.add(Colores3);
		
		Gestion = new JTextField();
		Gestion.setText("Gestion Tecnologica");
		Gestion.setBounds(10, 362, 178, 20);
		contentPane.add(Gestion);
		Gestion.setBackground(Color.red);
		Gestion.setColumns(10);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(Colores.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-25";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if(SemestreEXP.getSelectedIndex() == 0 || SemestreEXP.getSelectedIndex() == 1 || SemestreEXP.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia = "1-CT-IS-25";
			            	
			            	if( Colores.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreEXP.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores2.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-26";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreADMPII.getSelectedIndex()== 0 || SemestreADMPII.getSelectedIndex() == 1 || SemestreGETEC.getSelectedIndex() == 2) {	
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-26";
			            	
			            	if( Colores2.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreADMPII.getSelectedItem();
								status="certificado";
							}else {
								if( Colores2.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
								}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores3.getSelectedIndex() == 2) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-27";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestreGETEC.getSelectedIndex() == 0 || SemestreGETEC.getSelectedIndex() == 1 || SemestreGETEC.getSelectedIndex() == 2) {	
							String semestre = null;
							
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-27";
			            	
			            	if( Colores3.getSelectedIndex() == 1 ) {
								semestre = (String)SemestreGETEC.getSelectedItem();
								status="certificado";
			            	}else {
			            		if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
						
						}
					}
	
					JOptionPane.showMessageDialog(null, "Registro exitoso");
					OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
					visible.setVisible(true);
					setVisible(false);
				
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Registro fallido");
				}
			}
		});
		btnRegistrar.setBounds(10, 433, 139, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblMateriasQueNo = new JLabel("Materias que NO has cursado o NO has pasado dejalas en ROJO");
		lblMateriasQueNo.setFont(new Font("Stencil", Font.PLAIN, 12));
		lblMateriasQueNo.setBounds(10, 131, 424, 22);
		contentPane.add(lblMateriasQueNo);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnRegresar.setBounds(426, 433, 104, 23);
		contentPane.add(btnRegresar);
		
		JLabel lblSiNoHas = new JLabel("Si no has CURSADO o CERTIFICADO ninguna solo OPRIME registrar");
		lblSiNoHas.setFont(new Font("Stencil", Font.PLAIN, 16));
		lblSiNoHas.setBounds(7, 164, 558, 36);
		contentPane.add(lblSiNoHas);
		
		JLabel lblEnCasoDe = new JLabel("En caso de optimir certificado");
		lblEnCasoDe.setBounds(426, 199, 167, 14);
		contentPane.add(lblEnCasoDe);
		
		JLabel lblInicaEnQue = new JLabel("indica en que semestre\r\n");
		lblInicaEnQue.setBounds(426, 224, 167, 14);
		contentPane.add(lblInicaEnQue);
		
	}
}