package control;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Validacion;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Modificar extends JFrame {

	private JPanel contentPane;
	private static JTextField textNoCasa;
	private static JTextField textCorreoPersonal;
	private static JTextField textNoCelular;
	private int accesoNumero=0;
	private int accesoNCorreo=0;
	private int accesoCelular=0;
	
	
	/**
	 * Create the frame.
	 */
	public Modificar(Estudiante estudiante) {
		setTitle("Modificar Datos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIngresaElDato = new JLabel("Selecciona boton del dato que quieres modificar");
		lblIngresaElDato.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 16));
		lblIngresaElDato.setBounds(10, 21, 350, 19);
		contentPane.add(lblIngresaElDato);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.setBounds(318, 227, 89, 23);
		btnRegresar.addActionListener(new ActionListener() {
		      public void actionPerformed(ActionEvent arg0) {
		        LoginEstudiante login = new LoginEstudiante(estudiante);
		        setVisible(false);
		        login.setVisible(true);
		      }
		    });
		contentPane.add(btnRegresar);
		
		textNoCasa = new JTextField();
		textNoCasa.setBounds(10, 51, 147, 20);
		contentPane.add(textNoCasa);
		textNoCasa.setColumns(10);
		textNoCasa.setEditable(false);
		
		textNoCelular = new JTextField();
		textNoCelular.setColumns(10);
		textNoCelular.setBounds(10, 112, 147, 20);
		contentPane.add(textNoCelular);
		textNoCelular.setEditable(false);
		
		textCorreoPersonal = new JTextField();
		textCorreoPersonal.setColumns(10);
		textCorreoPersonal.setBounds(10, 176, 147, 20);
		contentPane.add(textCorreoPersonal);
		textCorreoPersonal.setEditable(false);
		
		JButton btnNoCasa = new JButton("Numero  Casa");
		btnNoCasa.setBounds(211, 50, 132, 23);
		btnNoCasa.addActionListener(new ActionListener() {
		      public void actionPerformed(ActionEvent arg0) {
		        textNoCasa.setEditable(true);
		        accesoNumero=1;
		      }
		    });
		contentPane.add(btnNoCasa);
		
		JButton btnNumeroCelular = new JButton("Numero  Celular");
		btnNumeroCelular.setBounds(211, 111, 132, 23);
		btnNumeroCelular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					textNoCelular.setEditable(true);
					accesoCelular=1;
				}
			});
		contentPane.add(btnNumeroCelular);
		
		JButton btnCorreoPersonal = new JButton("Correo Personal");
		btnCorreoPersonal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textCorreoPersonal.setEditable(true);
				accesoNCorreo=1;
			}
		});
		btnCorreoPersonal.setBounds(211, 175, 132, 23);
		contentPane.add(btnCorreoPersonal);
		
		JButton btnContinuar = new JButton("Modificar");
		btnContinuar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Estudiante guardar = new Estudiante();
				Estudiante respldo = new Estudiante();
	    		EstudianteIMPA acceder = new EstudianteIMPA();
	    		Validacion invocar = new Validacion();
	    		
	    		guardar.setCorreoInstitucional(Bienvenida.txtCorreoInstitucional.getText());
	    		respldo = acceder.consultarEstudianteAcceso(guardar);
				
	    		if(accesoNumero == 1) {
			
		    		boolean verificar = false;
		        
		        	String numero = Modificar.textNoCasa.getText();
		        
		        	verificar = invocar.validarNumCasa(numero);
		      
		        
		        if(verificar == true) {
		    		textNoCasa.setBackground(Color.green);
			        
		    		int otro = 0;
			        otro = acceder.modificarEstudiante(respldo, numero,1);
			        	if(otro == 1) {
			        			JOptionPane.showMessageDialog(null, "Modificacion de numero de casa exitosa");
			        			accesoNumero=0;
			        		}
			        }else {
			        	textNoCasa.setBackground(Color.red);
			        	JOptionPane.showMessageDialog(null, "Ingresa correctamente el numero de casa");
		        }
			}
				if(accesoCelular == 1) {
		    		boolean verificar = false;
		        
		        	String numeroCelular = Modificar.textNoCelular.getText();
		        
		        	verificar = invocar.validarNumTel(numeroCelular);
		      
		        
		        if(verificar == true) {
		    		textNoCelular.setBackground(Color.green);
			        
		    		int otro = 0;
			        otro = acceder.modificarEstudiante(respldo, numeroCelular,2);
			        	if(otro == 1) {
			        			JOptionPane.showMessageDialog(null, "Modificacion de celular exitosa");
			        			accesoCelular=0;
			        	}
			        }else {
		        	textNoCelular.setBackground(Color.red);
		        	JOptionPane.showMessageDialog(null, "Ingresa correctamente el numero de celular");
		        }
			}
				if(accesoNCorreo == 1) {
		    		boolean verificar = false;
		        
		        	String correo = Modificar.textCorreoPersonal.getText();
		        
		        	verificar = invocar.validarCorreoPersonal(correo);
		      
		        
		        if(verificar == true) {
		        	textCorreoPersonal.setBackground(Color.green);
			        
		    		int otro = 0;
			        otro = acceder.modificarEstudiante(respldo, correo,3);
			        	if(otro == 1) {
			        			JOptionPane.showMessageDialog(null, "Modificacion de correo exitosa");
			        			accesoNCorreo = 0;
			        	}
			        }else {
			        	textCorreoPersonal.setBackground(Color.red);
			        	JOptionPane.showMessageDialog(null, "Ingresa correctamente el correo");
		        }
			}
			}
		});
		btnContinuar.setBounds(10, 227, 89, 23);
		contentPane.add(btnContinuar);
	}
}
