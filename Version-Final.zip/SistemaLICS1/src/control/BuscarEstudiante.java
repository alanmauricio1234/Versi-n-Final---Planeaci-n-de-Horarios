package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Profesor;
import modelo.Validacion;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BuscarEstudiante extends JFrame {

  private JPanel contentPane;
  private JTable tblDatos;
  private DefaultTableModel modelo;
  private JPanel panel;
  private JTextField txtMatricula;
  private JButton btnBuscar;
  private JButton btnRegresar;



  /**
   * Create the frame.
   */
  public BuscarEstudiante(Profesor profesor) {
    setTitle("Buscar Estudiante");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 639, 189);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JLabel lblIngresaLaMatrcula = new JLabel("Ingresa la matr\u00EDcula del estudiante");
    lblIngresaLaMatrcula.setHorizontalAlignment(SwingConstants.CENTER);
    contentPane.add(lblIngresaLaMatrcula, BorderLayout.NORTH);
    
    JScrollPane scrollPane = new JScrollPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);
    
    tblDatos = new JTable();
    tblDatos.setModel(new DefaultTableModel(
        new Object[][] {
        },
        new String[] {
          "Matricula", "Nombre", "Apellido Paterno", "Apellido Materno",
          "Correo Institucional", "Correo Personal", "Celular", "Numero de Casa"
        }
    ));
    scrollPane.setViewportView(tblDatos);
    
    panel = new JPanel();
    contentPane.add(panel, BorderLayout.SOUTH);
    
    txtMatricula = new JTextField();
    txtMatricula.setHorizontalAlignment(SwingConstants.CENTER);
    txtMatricula.setText("Matricula");
    panel.add(txtMatricula);
    txtMatricula.setColumns(10);
    
    btnBuscar = new JButton("Buscar");
    btnBuscar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String matricula = txtMatricula.getText();
        Validacion verifica = new Validacion();
        Estudiante estudianteHallado = null;
        Estudiante estudiante = new Estudiante();
        estudiante.setMatricula(matricula);
        EstudianteIMPA estudianteImp = new EstudianteIMPA();
        String[] fila;
        if (verifica.validarMatricula(matricula)) {
          estudianteHallado = estudianteImp.consultarEstudiante(estudiante);
          if (estudianteHallado != null) {
            modelo = (DefaultTableModel) tblDatos.getModel();
            fila = new String[8];
            fila[0] = estudianteHallado.getMatricula();
            fila[1] = estudianteHallado.getNombre();
            fila[2] = estudianteHallado.getApellidoP();
            fila[3] = estudianteHallado.getApellidoM();
            fila[4] = estudianteHallado.getCorreoInstitucional();
            fila[5] = estudianteHallado.getCorreoPersonal();
            fila[6] = estudianteHallado.getNumCelular();
            fila[7] = estudianteHallado.getNumCasa();
            modelo.addRow(fila);
            tblDatos.setModel(modelo);
          } else {
            JOptionPane.showMessageDialog(null, "El estudiante no est� registrado :(");
          }
        } else {
          JOptionPane.showMessageDialog(null, "Matricula incorrecta :(");
        }
        
      }
    });
    panel.add(btnBuscar);
    
    btnRegresar = new JButton("Regresar");
    btnRegresar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        LoginProfesor login = new LoginProfesor(profesor);
        setVisible(false);
        login.setVisible(true);
      }
    });
    panel.add(btnRegresar);
  }

}
