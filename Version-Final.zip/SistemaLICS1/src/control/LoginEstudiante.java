package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.CriteriosImp;
import basedatos.EstudianteIMPA;
import basedatos.UsuarioProfesorImp;
import modelo.Criterio;
import modelo.Cuenta;
import modelo.Estudiante;
import modelo.Historiales;
import modelo.UsuarioProfesor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;

public class LoginEstudiante extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
  public LoginEstudiante(Estudiante estudiante) {
    setTitle("Login");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 460, 342);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(null);
	
    
    JLabel lblNewLabel = new JLabel("\u00BFQue deseas realizar?");
    lblNewLabel.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 16));
    lblNewLabel.setBounds(10, 26, 167, 31);
    contentPane.add(lblNewLabel);
    
    JButton btnVerMapaCurricular = new JButton("Ver Mapa Curricular de Materias");
    btnVerMapaCurricular.setBounds(108, 70, 210, 23);
    btnVerMapaCurricular.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        MapaCurricular visible = new MapaCurricular(estudiante);
        visible.setVisible(true);
        setVisible(false);
      }
    });
    contentPane.add(btnVerMapaCurricular);

    JButton btnModificarAlgunDato = new JButton("Modificar algun dato Personal");
    btnModificarAlgunDato.setBounds(108, 117, 210, 23);
    btnModificarAlgunDato.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Modificar visible = new Modificar(estudiante);
        visible.setVisible(true);
        setVisible(false);
      }
    });
    contentPane.add(btnModificarAlgunDato);

    JButton btnContestarEncuesta = new JButton("Contestar encuesta");
    btnContestarEncuesta.setBounds(108, 163, 210, 23);
    btnContestarEncuesta.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        CriteriosImp criterios = new CriteriosImp();
        List<Criterio> lista = null;
        
        //Consultamos a la base de datos
        lista = criterios.consultar();
        if (lista.size() > 0) {
          Encuesta encuesta = new Encuesta(lista, estudiante);
          setVisible(false);
          encuesta.setVisible(true);
        } else {
          JOptionPane.showMessageDialog(null, "No hay encuesta por el momento :(");
        }
      }
    });
    contentPane.add(btnContestarEncuesta);

    JButton btnMenuPricipal = new JButton("Menu Principal");
    btnMenuPricipal.setBounds(313, 269, 121, 23);
    btnMenuPricipal.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Bienvenida visible = new Bienvenida();
        visible.setVisible(true);
        setVisible(false);
      }
    });
    contentPane.add(btnMenuPricipal);
  }
}
