package control;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;
import modelo.Validacion;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class MapaCurricular extends JFrame {

  private JPanel contentPane;
  private JTable tblDatos;
  private DefaultTableModel modelo;
  private JPanel panel;
  private JTextField txtMatricula;
  private JButton btnBuscar;
  private JButton btnRegresar;



  /**
   * Create the frame.
   */
  public MapaCurricular(Estudiante estudiante) {
    setTitle("Mapa Curricular");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 639, 189);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JScrollPane scrollPane = new JScrollPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);
    
    scrollPane.setViewportView(tblDatos);
    
    panel = new JPanel();
    contentPane.add(panel, BorderLayout.SOUTH);
    
   
    	String correoInstitucional = Bienvenida.txtCorreoInstitucional.getText();
    	ArrayList<Historiales> lista = new ArrayList<>();
    	
    	EstudianteIMPA estudianteImp = new EstudianteIMPA();
    	Estudiante estudiante1 = new Estudiante();
    	Estudiante hallado = new Estudiante();
    	estudiante1.setCorreoInstitucional(correoInstitucional);
    	
    	hallado = estudianteImp.consultarEstudianteAcceso(estudiante1);
    	lista = estudianteImp.consultarHistorial(hallado);
    	
        String[] fila = new String[4];
        tblDatos = new JTable();
        tblDatos.setModel(new DefaultTableModel(
        	new Object[][] {
        	},
        	new String[] {
        		"Tipo Semestre", "Matricula", "Nombre Materia", "Status"
        	}
        ));
        
        scrollPane.setViewportView(tblDatos);
        
          if (lista != null) {
        	  modelo = (DefaultTableModel) tblDatos.getModel();
            for(int i = 0; i < lista.size(); i++) {
            	 fila[0] = lista.get(i).getSemestre();
                 fila[1] = lista.get(i).getMatricula();
                 fila[2] = lista.get(i).getCve_materia();
                 fila[3] = lista.get(i).getStatus();
                 modelo.addRow(fila);
            }
            tblDatos.setModel(modelo);
          }
    btnRegresar = new JButton("Regresar");
    btnRegresar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        LoginEstudiante login = new LoginEstudiante(estudiante);
        setVisible(false);
        login.setVisible(true);
      }
    });
    panel.add(btnRegresar);
  }

}
