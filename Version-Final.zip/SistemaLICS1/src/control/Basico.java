package control;


import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Historiales;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Basico extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	EstudianteIMPA invocar = new EstudianteIMPA();
	private String semestre;
    private String matricula;
	private String cve_materia;
	private String status;
	
	Historiales acceder = new Historiales();

	private JPanel contentPane;
    public static JTextField reciboNombre;
    public static JTextField reciboContrasena;
    public static JTextField IP;
    public static JTextField IS;
    public static JTextField ESDD;
    public static JTextField POO;
    private JTextField textMatematicas;

	/**
	 * Create the frame.
	 */
	public Basico(Estudiante estudiante, Historiales historial) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 619, 610);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		reciboNombre = new JTextField(estudiante.getNombre());
		reciboNombre.setEditable(false);
		reciboNombre.setBounds(98, 11, 200, 20);
		contentPane.add(reciboNombre);
		reciboNombre.setColumns(10);
		
		reciboContrasena = new JTextField(estudiante.getMatricula());
		reciboContrasena.setEditable(false);
		reciboContrasena.setBounds(98, 53, 200, 20);
		contentPane.add(reciboContrasena);
		reciboContrasena.setColumns(10);
		
		IP = new JTextField();
		IP.setText("Introduccion a la Programacion");
		IP.setBounds(10, 310, 178, 20);
		contentPane.add(IP);
	    IP.setBackground(Color.red);
		IP.setColumns(10);
		
		JList list = new JList();
		list.setBounds(226, 150, 43, -44);
		contentPane.add(list);
		
		JComboBox SemestreIP = new JComboBox();
		SemestreIP.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreIP.setBounds(441, 309, 89, 22);
		contentPane.add(SemestreIP);
		SemestreIP.setVisible(false);
		
	    JComboBox Colores = new JComboBox();
		Colores.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores.getSelectedIndex();
		        if( indice == 1){
		        	IP.setBackground(Color.green);
		        	SemestreIP.setVisible(true);
		        }else{
		            if(indice == 2){
		            	IP.setBackground(Color.yellow);
		            	SemestreIP.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		IP.setBackground(Color.red);
		            		SemestreIP.setVisible(false);
		            	}
		            }
		        }		        
			}
		});
		Colores.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores.setBounds(215, 310, 150, 20);
		contentPane.add(Colores);
		
		JLabel lblAlumno = new JLabel("ALUMNO");
		lblAlumno.setBounds(10, 14, 57, 14);
		contentPane.add(lblAlumno);
		
		JLabel lblMatricula = new JLabel("MATRICULA");
		lblMatricula.setBounds(10, 56, 77, 14);
		contentPane.add(lblMatricula);
		
		JLabel lblMarcaConVerde = new JLabel("Marca con Verde las materias que has certificado");
		lblMarcaConVerde.setBounds(10, 81, 299, 14);
		contentPane.add(lblMarcaConVerde);
		
		JLabel lblMarcaConAmarillo = new JLabel("Marca con Amarillo las materias que estas cursando");
		lblMarcaConAmarillo.setBounds(10, 106, 310, 14);
		contentPane.add(lblMarcaConAmarillo);
		
		IS = new JTextField();
		IS.setText("Ingenieria de Software");
		IS.setColumns(10);
		IS.setBounds(10, 363, 178, 20);
		IS.setBackground(Color.red);
		contentPane.add(IS);
		
		JComboBox SemestreIS = new JComboBox();
		SemestreIS.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreIS.setBounds(441, 362, 89, 22);
		contentPane.add(SemestreIS);
		SemestreIS.setVisible(false);
		
		final JComboBox Colores2 = new JComboBox();
		Colores2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores2.getSelectedIndex();
		        if( indice == 1){
		        	IS.setBackground(Color.green);
		        	SemestreIS.setVisible(true);
		        }else{
		            if(indice == 2){
		                IS.setBackground(Color.yellow);
		                SemestreIS.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		IS.setBackground(Color.red);
		            		SemestreIS.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores2.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores2.setBounds(215, 363, 150, 20);
		contentPane.add(Colores2);
		
		JComboBox SemestrePOO = new JComboBox();
		SemestrePOO.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestrePOO.setBounds(441, 415, 89, 22);
		contentPane.add(SemestrePOO);
		SemestrePOO.setVisible(false);
		
		final JComboBox Colores3 = new JComboBox();
		Colores3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores3.getSelectedIndex();
		        if( indice == 1){
		        	POO.setBackground(Color.green);
		        	SemestrePOO.setVisible(true);
		        }else{
		            if(indice == 2){
		                POO.setBackground(Color.yellow);
		                SemestrePOO.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		POO.setBackground(Color.red);
		            		SemestrePOO.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores3.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores3.setBounds(215, 416, 150, 20);
		contentPane.add(Colores3);
		
		POO = new JTextField();
		POO.setText("Orientada a Objetos");
		POO.setBounds(10, 416, 178, 20);
		contentPane.add(POO);
		POO.setBackground(Color.red);
		POO.setColumns(10);
		
		JComboBox SemestreEDD = new JComboBox();
		SemestreEDD.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreEDD.setBounds(441, 469, 89, 22);
		contentPane.add(SemestreEDD);
		SemestreEDD.setVisible(false);
		
		ESDD = new JTextField();
		ESDD.setBounds(10, 470, 178, 20);
		ESDD.setText("Estructura de Datos");
		contentPane.add(ESDD);
		ESDD.setBackground(Color.red);
		ESDD.setColumns(10);
		
		
		final JComboBox Colores4 = new JComboBox();
		Colores4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores4.getSelectedIndex();
		        if( indice == 1){
		        	ESDD.setBackground(Color.green);
		        	SemestreEDD.setVisible(true);
		        }else{
		            if(indice == 2){
		                ESDD.setBackground(Color.yellow);
		                SemestreEDD.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		ESDD.setBackground(Color.red);
		            		SemestreEDD.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores4.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores4.setBounds(215, 470, 150, 20);
		contentPane.add(Colores4);
		
		textMatematicas = new JTextField();
		textMatematicas.setText("Matematicas Discretas");
		textMatematicas.setColumns(10);
		textMatematicas.setBackground(Color.RED);
		textMatematicas.setBounds(10, 261, 178, 20);
		contentPane.add(textMatematicas);
		
		JComboBox SemestreMAT = new JComboBox();
		SemestreMAT.setModel(new DefaultComboBoxModel(new String[] {"2018-I", "2018-II", "2019-I"}));
		SemestreMAT.setBounds(441, 260, 89, 22);
		contentPane.add(SemestreMAT);
		SemestreMAT.setVisible(false);
		
		JComboBox Colores6 = new JComboBox();
		Colores6.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int indice = Colores6.getSelectedIndex();
		        if( indice == 1){
		        	textMatematicas.setBackground(Color.green);
		        	SemestreMAT.setVisible(true);
		        }else{
		            if(indice == 2){
		                textMatematicas.setBackground(Color.yellow);
		                SemestreMAT.setVisible(false);
		            }else {
		            	if(indice == 0) {
		            		textMatematicas.setBackground(Color.red);
		            		SemestreMAT.setVisible(false);
		            	}
		            }
		        }
			}
		});
		Colores6.setModel(new DefaultComboBoxModel(new String[] {"No Certificado", "Certificado", "Cursando"}));
		Colores6.setBounds(215, 261, 150, 20);
		contentPane.add(Colores6);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String matriculaActual = Registro.textMatricula.getText();
				estudiante.setMatricula(matriculaActual);
			
				try {
					if(Colores.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IF-01";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
		            		JOptionPane.showMessageDialog(null, "Solo puedes estar cursando 7 materias");
		            	}
					}else {
						if(SemestreIP.getSelectedIndex() == 0 || SemestreIP.getSelectedIndex() == 1 || SemestreIP.getSelectedIndex() == 2) {
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IF-01";
			            	
			            	if( Colores.getSelectedIndex() == 1 ) {
			            		status="certificado";
								semestre = (String)SemestreIP.getSelectedItem();
			            	}else {
			            		if( Colores.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores2.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-02";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "Solo puedes estar crsando 7 materias");
						}
						}else {
						if( SemestreIS.getSelectedIndex()== 0 || SemestreIS.getSelectedIndex() == 1 || SemestreIS.getSelectedIndex() == 2) {	
							String semestre = null;
						
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IS-02";
			            	
			            	if( Colores2.getSelectedIndex() == 1 ) {
			            		status="certificado";
								semestre = (String)SemestreIS.getSelectedItem();
			            	}else {
			            		if( Colores2.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
					
						}
					}
					if(Colores3.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IF-02";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "solo puedes estar cursando 7 materias");
						}
					}else {
						if( SemestrePOO.getSelectedIndex() == 0 || SemestrePOO.getSelectedIndex() == 1 || SemestrePOO.getSelectedIndex() == 2) {	
							String semestre = null;
							
							matricula = Registro.textMatricula.getText();
			            	cve_materia="1-CT-IF-02";
			            	
			            	if( Colores3.getSelectedIndex() == 1 ) {
			            		status="certificado";
								semestre = (String)SemestrePOO.getSelectedItem();
			            	}else {
			            		if( Colores3.getSelectedIndex() == 0 ) {
								semestre = "2019-II";
							    status = "No certificado";
			            		}
							}
			            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
			            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores4.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-03";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							
						}
						}else {
						if( SemestreEDD.getSelectedIndex( ) == 0 || SemestreEDD.getSelectedIndex() == 1 || SemestreEDD.getSelectedIndex() == 2) {	
							
							String semestre = null;
		
								matricula = Registro.textMatricula.getText();
				            	cve_materia="1-CT-IS-03";
				            	
				            	if( Colores4.getSelectedIndex() != 0 ) {
									semestre = (String)SemestreEDD.getSelectedItem();
									status="certificado";
				            	}else {
				            		if( Colores4.getSelectedIndex() == 0 ) {
									semestre = "2019-II";
								    status = "No certificado";
				            		}
								}
				            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
				            	invocar.insertarHistorial(historial);
						
						}
					}
					if(Colores6.getSelectedIndex() == 2 ) {
						if( invocar.contarCursando(estudiante) < 7 ) {
						semestre="2019-II";
		            	matricula = Registro.textMatricula.getText();
		            	cve_materia="1-CT-IS-01";
		            	status="cursando";
		            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
		            	
		            	invocar.insertarHistorial(historial);
						}else {
							JOptionPane.showMessageDialog(null, "Solo puedes estar cursando 7 materias");
						}
						}else {
						if( SemestreMAT.getSelectedIndex( ) == 0 || SemestreMAT.getSelectedIndex() == 1 || SemestreMAT.getSelectedIndex() == 2) {	
							
							String semestre = null;
		
								matricula = Registro.textMatricula.getText();
				            	cve_materia="1-CT-IS-01";
				            	
				            	if( Colores6.getSelectedIndex() != 0 ) {
									semestre = (String)SemestreMAT.getSelectedItem();
									status="certificado";
				            	}else {
				            		if( Colores6.getSelectedIndex() == 0 ) {
									semestre = "2019-II";
								    status = "No certificado";
				            		}
								}
				            	Historiales historial = new Historiales(semestre,matricula,cve_materia,status);
				            	invocar.insertarHistorial(historial);
						
						}
					}
					JOptionPane.showMessageDialog(null, "Registro exitoso");
					OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
					visible.setVisible(true);
					setVisible(false);
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Registro fallido");
				}
			}
		});
		btnRegistrar.setBounds(10, 537, 139, 23);
		contentPane.add(btnRegistrar);
		
		JLabel lblMateriasQueNo = new JLabel("Materias que NO has cursado o NO has pasado dejalas en ROJO");
		lblMateriasQueNo.setFont(new Font("Stencil", Font.PLAIN, 12));
		lblMateriasQueNo.setBounds(10, 131, 424, 22);
		contentPane.add(lblMateriasQueNo);
		
		JButton btnRegresar = new JButton("Regresar");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OpcionHistorial visible = new OpcionHistorial(estudiante, historial);
				visible.setVisible(true);
				setVisible(false);
			}
		});
		btnRegresar.setBounds(426, 537, 104, 23);
		contentPane.add(btnRegresar);
		
		JLabel lblSiNoHas = new JLabel("Si no has CURSADO o CERTIFICADO ninguna solo OPRIME registrar");
		lblSiNoHas.setFont(new Font("Stencil", Font.PLAIN, 16));
		lblSiNoHas.setBounds(7, 164, 558, 36);
		contentPane.add(lblSiNoHas);
		
		JLabel lblEnCasoDe = new JLabel("En caso de optimir certificado");
		lblEnCasoDe.setBounds(426, 199, 167, 14);
		contentPane.add(lblEnCasoDe);
		
		JLabel lblInicaEnQue = new JLabel("indica en que semestre\r\n");
		lblInicaEnQue.setBounds(426, 224, 167, 14);
		contentPane.add(lblInicaEnQue);
		
	}
}