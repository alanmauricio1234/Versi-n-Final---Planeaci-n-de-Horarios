package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import basedatos.InscripcionImp;
import modelo.Criterio;
import modelo.Estudiante;
import modelo.Horario;
import modelo.Inscripcion;

import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;

public class Encuesta extends JFrame {

  private JPanel contentPane;
  private Inscripcion inscripcion;
  private DefaultTableModel modelo;
  private JTable tblDatos;
  private DefaultComboBoxModel<Object> modeloSemestre;
  
  
  /**Constructor de la ventana.*/
  public Encuesta(List<Criterio> lista, Estudiante estudiante) {
    setTitle("Encuesta");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 593, 404);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    inscripcion = new Inscripcion();
   
    JPanel panelSuperior = new JPanel();
    panelSuperior.setBorder(null);
    contentPane.add(panelSuperior, BorderLayout.NORTH);
    panelSuperior.setLayout(new GridLayout(2, 1, 0, 0));
   
    JLabel lblBienvenido = new JLabel("Bienvenido a la encuesta para la planificacion de horarios");
    lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
    panelSuperior.add(lblBienvenido);
   
    JLabel lblRecuerda = new JLabel("Recuerda que las materias de ciclo basico se abren todos"
           + " los semestres\r\n");
    lblRecuerda.setHorizontalAlignment(SwingConstants.CENTER);
    panelSuperior.add(lblRecuerda);
   
    JPanel panelInferior = new JPanel();
    contentPane.add(panelInferior, BorderLayout.SOUTH);
    panelInferior.setLayout(new BorderLayout(0, 0));
   
    JPanel panelEnviar = new JPanel();
    panelEnviar.setBorder(null);
    panelInferior.add(panelEnviar, BorderLayout.EAST);
   
    JButton btnEnviar = new JButton("Enviar");
    btnEnviar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String cad = "Se muestran los cursos enviados... \n";
        cad += inscripcion.toString();
        JOptionPane.showMessageDialog(null, cad);
        //Eliminar las filas de la tabla
        DefaultTableModel modelo = (DefaultTableModel) tblDatos.getModel();
        tblDatos.setModel(modelo);
        if (inscripcion.getTam() > 0) {
          //Insertamos los datos en la base de datos
          InscripcionImp inscripcionImp = new InscripcionImp();
          System.out.println(estudiante.getMatricula());
          for (int i = 0; i < inscripcion.getTam(); i++) {
            inscripcionImp.insertar(inscripcion, estudiante, i);
          }
          inscripcion.eliminarHorarios();
          LoginEstudiante login = new LoginEstudiante(estudiante);
          setVisible(false);
          login.setVisible(true);
        }
      }
    });
    panelEnviar.add(btnEnviar);
   
    JPanel panelAgregar = new JPanel();
    panelAgregar.setBorder(null);
    panelInferior.add(panelAgregar, BorderLayout.WEST);
    
    JComboBox cmbTurno = new JComboBox();
    cmbTurno.setModel(new DefaultComboBoxModel(new String[] {"Matutino", "Vespertino"}));
    
    JComboBox cmbMateria = new JComboBox();
    
    JComboBox cmbSemestre = new JComboBox();
    //Agregar los semestres
    for (int i = 0; i < lista.size(); i++) {
      cmbSemestre.addItem(lista.get(i).getSemestre());
    }
    String[] materias = seleccionarMaterias(lista.get(0).getSemestre());
    modeloSemestre = new DefaultComboBoxModel<Object>(materias);
    cmbMateria.setModel(modeloSemestre);
    cmbSemestre.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String item = (String) cmbSemestre.getSelectedItem();
          cmbMateria.removeAllItems();
          switch (item) {
            case "5to semestre": {
              cmbMateria.addItem("Analisis de algoritmos");
              cmbMateria.addItem("Teoria de la computacion");
              cmbMateria.addItem("Construccion y evolucion del software");
              cmbMateria.addItem("Bases de datos");
              cmbMateria.addItem("Analisis de requisitos");
              break;
            }
            case "6to semestre": {
              cmbMateria.addItem("Programacion web");
              cmbMateria.addItem("Sistemas operativos");
              cmbMateria.addItem("Aseguramiento de la calidad del software");
              cmbMateria.addItem("Analisis y modelamiento de software");
              cmbMateria.addItem("Programacion de sistemas");
              break;
            }
            case "7mo semestre": {
              cmbMateria.addItem("Arquitectura de computadoras");
              cmbMateria.addItem("Lenguajes de programacion");
              cmbMateria.addItem("Tecnicas de pruebas de software");
              cmbMateria.addItem("Dise�o de software");
              cmbMateria.addItem("Metodologia de la investigacion");
              break;
            }
            case "8vo semestre": {
              cmbMateria.addItem("Redes de computadoras");
              cmbMateria.addItem("Normatividad y legislacion");
              cmbMateria.addItem("Arquitectura de software");
              break;
            }
            case "9no semestre": {
              cmbMateria.addItem("Sistemas distribuidos");
              cmbMateria.addItem("Administracion de proyectos I");
              cmbMateria.addItem("Metricas de software");
              break;
            }
            case "10mo semestre": {
              cmbMateria.addItem("Dise�o de experimentos en ingenieria de software");
              cmbMateria.addItem("Administracion de proyectos II");
              cmbMateria.addItem("Gestion tecnologica");
              break;
            }
            case "Aplicaciones web": {
              cmbMateria.addItem("XML 1");
              cmbMateria.addItem("XML 2");
              cmbMateria.addItem("Mapeo objeto/relacional");
              break;
            }
            case "Inteligencia artificial": {
              cmbMateria.addItem("Inteligencia artificial");
              cmbMateria.addItem("Seminario de inteligencia artificial I");
              cmbMateria.addItem("Seminario de inteligencia artificial II");
              break;
            }
            case "Sistemas moviles y embebidos": {
              cmbMateria.addItem("Computacion movil");
              cmbMateria.addItem("Sistemas embebidos");
              cmbMateria.addItem("Sistemas en tiempo real");
              break;
            }
            case "Tecnologias de bases de datos": {
              cmbMateria.addItem("Especialidad en bases de datos I");
              cmbMateria.addItem("Especialidad en bases de datos II");
              cmbMateria.addItem("Administracion de bases de datos");
              cmbMateria.addItem("Inteligencia de negocios");
              break;
            }
            default: {
      
            }
          }
        }
      });
   
    JButton btnAgregar = new JButton("Agregar");
    btnAgregar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        String semestre = (String) cmbSemestre.getSelectedItem();
        String nomMateria = (String) cmbMateria.getSelectedItem();
        String turno = (String) cmbTurno.getSelectedItem();
        
        //Creamos el horario
        Horario horario = inscripcion.crearHorario(nomMateria, semestre, turno);
        if (inscripcion.equals(horario)) {
          JOptionPane.showMessageDialog(null, "La materia ya se agrego :(");
        } else {
          if (inscripcion.getTam() <= 6) {
            //Agregamos el horarios
            inscripcion.agregarHorario(horario);
            modelo = (DefaultTableModel) tblDatos.getModel();
            //Creamos la fila
            String [] fila = new String[4];
            fila[0] = horario.getMateria().getClave();
            fila[1] = semestre;
            fila[2] = nomMateria;
            fila[3] = turno;
            //Agregamos la materia
            modelo.addRow(fila);
            //Insertamos el modelo
            tblDatos.setModel(modelo);
          } else {
            JOptionPane.showMessageDialog(null, "No se pueden agregar m�s materias :(");
          }
        }
      }
    });
    panelAgregar.add(btnAgregar);
   
    JButton btnEliminar = new JButton("Eliminar");
    btnEliminar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
          //almacenamos la fila seleccionada
          int fila = tblDatos.getSelectedRow();
          if (fila >= 0 && fila < inscripcion.getTam()) {
            modelo = (DefaultTableModel) tblDatos.getModel();
            //Eliminamos el horario
            inscripcion.eliminarHorario(fila);
            //Eliminamos la fila
            modelo.removeRow(fila);
            tblDatos.setModel(modelo);
        } else {
              JOptionPane.showMessageDialog(null, "Seleccione una fila :)");
          }
      }
    });
    panelAgregar.add(btnEliminar);
   
    JPanel panelCentral = new JPanel();
    panelCentral.setBorder(null);
    contentPane.add(panelCentral, BorderLayout.CENTER);
    panelCentral.setLayout(new GridLayout(3, 2, 0, 0));
   
    JPanel panelComboBox = new JPanel();
    panelComboBox.setBorder(null);
    panelCentral.add(panelComboBox);
    panelComboBox.setLayout(new GridLayout(3, 2, 0, 0));
   
    JPanel panelSemestre = new JPanel();
    panelSemestre.setBorder(null);
    panelComboBox.add(panelSemestre);
    
    JPanel panelMateria = new JPanel();
    panelMateria.setBorder(null);
    panelComboBox.add(panelMateria);
   
    JLabel lblMateria = new JLabel("Materia");
    lblMateria.setHorizontalAlignment(SwingConstants.CENTER);
    panelMateria.add(lblMateria);
    
    panelMateria.add(cmbMateria);
    JLabel lblSemestreoptativa = new JLabel("Semestre/Optativa");
    panelSemestre.add(lblSemestreoptativa);   
    panelSemestre.add(cmbSemestre);

    JPanel panelTurno = new JPanel();
    panelTurno.setBorder(null);
    panelComboBox.add(panelTurno);
   
    JLabel lblTurno = new JLabel("Turno");
    panelTurno.add(lblTurno);
   
    panelTurno.add(cmbTurno);
   
    JPanel panelTabla = new JPanel();
    panelCentral.add(panelTabla);
    panelTabla.setLayout(new BorderLayout(0, 0));
   
    JScrollPane scrollPane = new JScrollPane();
    panelTabla.add(scrollPane);
   
    tblDatos = new JTable();
    tblDatos.setModel(new DefaultTableModel(
        new Object[][] {
        },
        new String[] {
          "Clave", "Semestre/Optativa", "Materia", "Turno"
        }
    ));
    scrollPane.setViewportView(tblDatos);
   
    JPanel panelComentarios = new JPanel();
    panelCentral.add(panelComentarios);
    panelComentarios.setLayout(new GridLayout(2, 0, 0, 0));
   
    JPanel panelEtiquetaComentario = new JPanel();
    panelEtiquetaComentario.setBorder(null);
    panelComentarios.add(panelEtiquetaComentario);
    panelEtiquetaComentario.setLayout(new BorderLayout(0, 0));
   
    JLabel lblComentarios = new JLabel("Comentarios");
    lblComentarios.setHorizontalAlignment(SwingConstants.CENTER);
    panelEtiquetaComentario.add(lblComentarios, BorderLayout.WEST);
   
    JPanel panelArea = new JPanel();
    panelArea.setBorder(null);
    panelComentarios.add(panelArea);
    panelArea.setLayout(new BorderLayout(0, 0));
   
    JTextArea textArea = new JTextArea();
    textArea.setWrapStyleWord(true);
    textArea.setLineWrap(true);
    panelArea.add(textArea);
  }
  
  private String[] seleccionarMaterias(String semestre) {
    String[] materias = null;
    switch (semestre) {
      case "5to semestre": {
        materias = new String[5];
        materias[0] = "Analisis de algoritmos";
        materias[1] = "Teoria de la computacion";
        materias[2] = "Construccion y evolucion del software";
        materias[3] = "Bases de datos";
        materias[4] = "Analisis de requisitos";
        break;
      }
      case "6to semestre": {
        materias = new String[5];
        materias[0] = "Programacion web";
        materias[1] = "Sistemas operativos";
        materias[2] = "Aseguramiento de la calidad del software";
        materias[3] = "Analisis y modelamiento de software";
        materias[4] = "Programacion de sistemas";
        break;
      }
      case "7mo semestre": {
        materias = new String[5];
        materias[0] = "Arquitectura de computadoras";
        materias[1] = "Lenguajes de programacion";
        materias[2] = "Tecnicas de pruebas de software";
        materias[3] = "Dise�o de software";
        materias[4] = "Metodologia de la investigacion";
        break;
      }
      case "8vo semestre": {
        materias = new String[3];
        materias[0] = "Redes de computadoras";
        materias[1] = "Normatividad y legislacion";
        materias[2] = "Arquitectura de software";
        break;
      }
      case "9no semestre": {
        materias = new String[3];
        materias[0] = "Sistemas distribuidos";
        materias[1] = "Administracion de proyectos I";
        materias[2] = "Metricas de software";
        break;
      }
      case "10mo semestre": {
        materias = new String[3];
        materias[0] = "Dise�o de experimentos en ingenieria de software";
        materias[1] = "Administracion de proyectos II";
        materias[2] = "Gestion tecnologica";
        break;
      }
      case "Aplicaciones web": {
        materias = new String[3];
        materias[0] = "XML 1";
        materias[1] = "XML 2";
        materias[2] = "Mapeo objeto/relacional";
        break;
      }
      case "Inteligencia artificial": {
        materias = new String[3];
        materias[0] = "Inteligencia artificial";
        materias[1] = "Seminario de inteligencia artificial I";
        materias[2] = "Seminario de inteligencia artificial II";
        break;
      }
      case "Sistemas moviles y embebidos": {
        materias = new String[3];
        materias[0] = "Computacion movil";
        materias[1] = "Sistemas embebidos";
        materias[2] = "Sistemas en tiempo real";
        break;
      }
      case "Tecnologias de bases de datos": {
        materias = new String[4];
        materias[0] = "Especialidad en bases de datos I";
        materias[1] = "Especialidad en bases de datos II";
        materias[2] = "Administracion de bases de datos";
        materias[3] = "Inteligencia de negocios";
        break;
      }
      default: {

      }
    }
    return materias;
  }
}
