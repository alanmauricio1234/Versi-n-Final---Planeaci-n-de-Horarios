package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import basedatos.CriteriosImp;
import basedatos.EstudianteIMPA;
import modelo.Estudiante;
import modelo.Materia;
import modelo.Profesor;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class LoginProfesor extends JFrame {

  private JPanel contentPane;



  /**
   * Create the frame.
   */
  public LoginProfesor(Profesor profesor) {
    setTitle("Login");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 404, 179);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JPanel panel = new JPanel();
    panel.setBorder(new LineBorder(new Color(0, 0, 0)));
    contentPane.add(panel, BorderLayout.CENTER);
    
    JButton btnGenerarEncuesta = new JButton("Generar Encuesta");
    btnGenerarEncuesta.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        GenerarEncuesta generar = new GenerarEncuesta(profesor);
        setVisible(false);
        generar.setVisible(true);
      }
    });
    panel.add(btnGenerarEncuesta);
    
    JButton btnRegistrados = new JButton("Registrados");
    btnRegistrados.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        List<Estudiante> estudiantes = null;
        EstudianteIMPA estudianteImp = new EstudianteIMPA();
        estudiantes = estudianteImp.consultar();
        if (estudiantes != null) {
          ListaEstudiantes registrados = new ListaEstudiantes(estudiantes, profesor);
          setVisible(false);
          registrados.setVisible(true);
        } else {
          JOptionPane.showMessageDialog(null, "No hay alumnos registrados");
        }
      }
    });
    panel.add(btnRegistrados);
    
    JButton btnBuscarEstudiante = new JButton("Buscar Estudiante");
    btnBuscarEstudiante.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        BuscarEstudiante buscar = new BuscarEstudiante(profesor);
        setVisible(false);
        buscar.setVisible(true);
      }
    });
    panel.add(btnBuscarEstudiante);
    
    JButton btnCerrarSesion = new JButton("Cerrar Sesion");
    btnCerrarSesion.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Bienvenida bienvenida = new Bienvenida();
        setVisible(false);
        bienvenida.setVisible(true);
      }
    });
    
    JButton btnEliminarcriterios = new JButton("Eliminar Criterios");
    btnEliminarcriterios.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        CriteriosImp criterios = new CriteriosImp();
        int eliminar = 0;
        eliminar = criterios.eliminarCriterios();
        if (eliminar != 0) {
          JOptionPane.showMessageDialog(null, "Se eliminaron los criterios :)");
        } else {
          JOptionPane.showMessageDialog(null, "No se eliminaron los criterios :(");
        }
      }
    });
    
    JButton btnConteos = new JButton("Conteos");
    btnConteos.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        Recomendaciones recomendaciones = new Recomendaciones(profesor);
        setVisible(false);
        recomendaciones.setVisible(true);
      }
    });
    
    panel.add(btnEliminarcriterios);
    panel.add(btnConteos);
    panel.add(btnCerrarSesion);
    
    
    JPanel panelNorte = new JPanel();
    contentPane.add(panelNorte, BorderLayout.NORTH);
    
    JLabel lblBienvenido = new JLabel("");
    lblBienvenido.setText("BIENVENIDO " + profesor.getNombre().toUpperCase()
        + " " + profesor.getApellidoP().toUpperCase() + " !!!");
    lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
    panelNorte.add(lblBienvenido);
  }

}
