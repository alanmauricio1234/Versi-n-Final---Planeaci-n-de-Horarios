package control;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import basedatos.EstudianteIMPA;
import basedatos.InscripcionImp;
import modelo.Estudiante;
import modelo.Historiales;
import modelo.Profesor;
import modelo.Validacion;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Recomendaciones extends JFrame {


  private static final long serialVersionUID = 1L;
  private JPanel contentPane;
  private JTable tblDatos;
  private DefaultTableModel modelo;
  private JPanel panel;
  private JTextField txtMatricula;
  private JButton btnBuscar;
  private JButton btnRegresar;
  InscripcionImp invocar = new InscripcionImp();
  ArrayList<modelo.Recomendaciones> lista = new ArrayList<>();


  /**
   * Create the frame.
   */
  public Recomendaciones(Profesor profesor) {
    setTitle("Conteos");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBounds(100, 100, 639, 189);
    contentPane = new JPanel();
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setContentPane(contentPane);
    contentPane.setLayout(new BorderLayout(0, 0));
    
    JScrollPane scrollPane = new JScrollPane();
    contentPane.add(scrollPane, BorderLayout.CENTER);
    
    scrollPane.setViewportView(tblDatos);
    
    panel = new JPanel();
    contentPane.add(panel, BorderLayout.SOUTH);
    
   
    String correoInstitucional = Bienvenida.txtCorreoInstitucional.getText();

    lista = invocar.conteoInscripciones();

    String[] fila = new String[2];
    tblDatos = new JTable();
    tblDatos.setModel(new DefaultTableModel(
        new Object[][] {
        },
        new String[] {
          "Materia", "Numero de Alumnos Inscritos"
        }
    ));

    scrollPane.setViewportView(tblDatos);

    /*if (lista != null) {
      modelo = (DefaultTableModel) tblDatos.getModel();
      for (int i = 0; i < lista.size(); i++) {
        
        fila[0] = lista.get(i).getNombre_materia();
        fila[1] = lista.get(i).getRecomendacion();
        modelo.addRow(fila);
      }
      tblDatos.setModel(modelo);
    }*/
    modelo = (DefaultTableModel) tblDatos.getModel();
    if (lista != null) {
      for (int i = 0; i < lista.size(); i++) {
        if (Integer.parseInt(lista.get(i).getRecomendacion()) >= 5) {
          fila[0] = lista.get(i).getNombre_materia();
          fila[1] = lista.get(i).getRecomendacion();
          modelo.addRow(fila);
        }
      }
      tblDatos.setModel(modelo);
    }
    
    
    btnRegresar = new JButton("Regresar");
    btnRegresar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        LoginProfesor login = new LoginProfesor(profesor);
        setVisible(false);
        login.setVisible(true);
      }
    });
    panel.add(btnRegresar);
  }

}
