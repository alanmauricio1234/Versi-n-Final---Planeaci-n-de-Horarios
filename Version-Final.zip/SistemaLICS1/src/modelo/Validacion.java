package modelo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validacion {
  
  public Validacion() {
    
  }
  
  /**Valida la matr�cula.*/
  public boolean validarMatricula(String matricula){
    //Cadena que representa la expresi�n regular
    boolean validar = false;
    String expresion = "[0-9]{2}[-](00)[1-5][-][0-9]{4}";
    Pattern patron = Pattern.compile(expresion); //Representamos la expresi�n regular
    Matcher m = patron.matcher(matricula); //Comprueba que el n�mero cumpla con el patron
    //Verificamos que la matr�cula cumpla con el patr�n
    boolean verificacion = m.matches();
    validar = verificacion;
    
    return validar;
    
  }
  
  /**Valida el correo personal.*/
  public boolean validarCorreoPersonal(String correoPersonal){
    boolean validar = false;
    String expresion = "[_a-zA-Z0-9.]+[@]" + "(hotmail|gmail|yahoo|outlook|live)"
            + "(.com)?(.mx)?";
    Pattern patron = Pattern.compile(expresion);//Representamos la expresi�n regular
    Matcher m = patron.matcher(correoPersonal);// Comprueba que el correo cumpla con el patron
    validar = m.matches();//Regresa el resultado de la verificaci�n del correo
    
    return validar;
  }
  
  /**Valida el correo institucional del profesor.*/
  public boolean validarCorreoInsProfesor(String correoInstitucional) {
    boolean verificar = false;
    String expresion = "[_a-zA-Z0-9.]+[@]"
           + "(uacm)(.edu)(.mx)";
    Pattern patron = Pattern.compile(expresion);
    Matcher m = patron.matcher(correoInstitucional);
    verificar = m.matches();
    
    return verificar;
  }
  
  /**Valida el correo institucional.*/
  public boolean validarCorreoInstitucional(String correoInstitucional) {
    boolean verificar = false;
    String expresion = "[_a-zA-Z0-9.]+[@]"
        + "(estudiante|alumnos)"
        + "(.uacm)(.edu)(.mx)";
    Pattern patron = Pattern.compile(expresion);//Representamos la expresi�n regular
    Matcher m = patron.matcher(correoInstitucional);//Comprueba que el correo cumpla con el patron
    verificar = m.matches();// Regresa el resultado de la verificaci�n del correo
 
    return verificar;
  }
  
  /**Valida el n�mero telef�nico de casa.*/
  public boolean validarNumCasa(String numCasa) {
    boolean verificar = false;
    String expresion = "(55)[0-9]{8}";
    Pattern patron = Pattern.compile(expresion);//Representamos el patron
    Matcher m = patron.matcher(numCasa);//Comprobamos que el numero de casa cumpla con el patron
    verificar = m.matches();//Regresa el resultado de la verificaci�n del n�mero

    return verificar;
  }
  
  /**Valida el correo institucional.*/
  public boolean validarNumTel(String numCelular) {
    boolean verificar = false;
    String expresion = "(55|56)[0-9]{8}";
    Pattern patron = Pattern.compile(expresion);//Representamos la expresi�n regular
    Matcher m = patron.matcher(numCelular);//Comprobamos que el n�mero cumpla con el patron
    verificar = m.matches();//Regresa el resultado de la verificaci�n del patron
    
    return verificar;
  }
  
  /**Verifica el n�mero de trabajador.*/
  public boolean validarNumTrabajador(String numeroTrabajador) {
    boolean verificar = false;
    String expresion = "[1-9][0-9]?[0-9]?[0-9]?[0-9]?";
    Pattern patron = Pattern.compile(expresion);
    Matcher m = patron.matcher(numeroTrabajador);
    verificar = m.matches();
    return verificar;
  }
  
  public boolean validarExtension(String extension) {
    boolean verificar = false;
    String expresion = "[0-9][0-9]?[0-9]?";
    Pattern patron = Pattern.compile(expresion);
    Matcher m = patron.matcher(extension);
    verificar = m.matches();
    return verificar;
  }
  
}
