package modelo;

public class Profesor extends Persona {
  private String numTrabajador;
  private String correoInstitucional;
  private String colegioAdscripcion;
  private String plantelAdscripcion;
  private String academia;
  private String cubiculo;
  private String extension;
  

  public Profesor() {
    super();
  }
  
  public String getNumTrabajador() {
    return numTrabajador;
  }
  
  public void setNumTrabajador(String numTrabajador) {
    this.numTrabajador = numTrabajador;
  }
  
  public String getCorreoInstitucional() {
    return correoInstitucional;
  }
  
  public void setCorreoInstitucional(String correoInstitucional) {
    this.correoInstitucional = correoInstitucional;
  }
  
  public String getColegioAdscripcion() {
    return colegioAdscripcion;
  }
  
  public void setColegioAdscripcion(String colegioAdscripcion) {
    this.colegioAdscripcion = colegioAdscripcion;
  }
  
  public String getPlantelAdscripcion() {
    return plantelAdscripcion;
  }
  
  public void setPlantelAdscripcion(String plantelAdscripcion) {
    this.plantelAdscripcion = plantelAdscripcion;
  }
  
  public String getAcademia() {
    return academia;
  }
  
  public void setAcademia(String academia) {
    this.academia = academia;
  }
  
  public String getCubiculo() {
    return cubiculo;
  }
  
  public void setCubiculo(String cubiculo) {
    this.cubiculo = cubiculo;
  }
  
  public String getExtension() {
    return extension;
  }

  public void setExtension(String extension) {
    this.extension = extension;
  }
   
  
}
