package modelo;
/*Cuenta Estudiante*/
public class Cuenta {
	private String correo_institucional;
	private String password;
	private String matricula;
	
	public Cuenta(String correo_institucional,String password,String matricula) {
		this.correo_institucional=correo_institucional;
		this.password=password;
		this.matricula=matricula;
	}
	
	public Cuenta() {
		
	}
	
	public String getCorreoInstitucional() {
		return correo_institucional;
	}
	public void setCorreoInstitucional(String correo_institucional) {
		this.correo_institucional = correo_institucional;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String toString() {
		String cadena=null;
		cadena="Id:"+correo_institucional+" Password:"+password+"Matricula"+matricula+"\n";	
		return cadena;
	}
}
