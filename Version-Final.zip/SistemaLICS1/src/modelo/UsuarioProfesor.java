package modelo;

public class UsuarioProfesor {
  private String numeroTrabajador;
  private String correoInstitucional;
  private String password;
  
  public UsuarioProfesor() {
    
  }
  
  public String getNumeroTrabajador() {
    return numeroTrabajador;
  }
  
  public void setNumeroTrabajador(String numeroTrabajador) {
    this.numeroTrabajador = numeroTrabajador;
  }
  
  public String getCorreoInstitucional() {
    return correoInstitucional;
  }
  
  public void setCorreoInstitucional(String correoInstitucional) {
    this.correoInstitucional = correoInstitucional;
  }
  
  public String getPassword() {
    return password;
  }
  
  public void setPassword(String password) {
    this.password = password;
  }
  
}
