package modelo;

import java.util.ArrayList;
import java.util.List;

public class Criterio {
  private String semestre;
  private String numTrabajador;
  
  public Criterio() {
    
  }
  
  public String getSemestre() {
    return semestre;
  }
  
  public void setSemestre(String semestre) {
    this.semestre = semestre;
  }
  
  public String getNumTrabajador() {
    return numTrabajador;
  }
  
  public void setNumTrabajador(String numTrabajador) {
    this.numTrabajador = numTrabajador;
  }
  
  /**M�todo equals.*/
  public boolean verifica(List<Criterio> criterios) {
    boolean band = false;
    for (int i = 0; i < criterios.size(); i++) {
      if (criterios.get(i).semestre.equals(this.semestre)) {
        band = true;
        break;
      }
    }
    return band;
  }
  
  /**M�todo equals.*/
  public boolean equals(Criterio criterio) {
    boolean igual = false;
    igual = this.semestre.equals(criterio.semestre);
    return igual;
  }
  
  
}
