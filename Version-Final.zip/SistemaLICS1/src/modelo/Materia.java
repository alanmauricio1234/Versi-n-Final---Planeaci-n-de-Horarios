package modelo;

public class Materia {
  private String nombre;
  private String semestre;
  private String clave;
  
  /**Es el contructor de la clase.*/
  public Materia(String nombre, String semestre) {
    this.nombre = nombre;
    this.semestre = semestre;
    asignarClave(nombre);
  }
  
  public Materia() {
    
  }


  public String getNombre() {
    return nombre;
  }
  
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  
  public String getSemestre() {
    return semestre;
  }
  
  public void setSemestre(String semestre) {
    this.semestre = semestre;
  }
  
  
  public String getClave() {
    return clave;
  }
  
  public void setClave() {
    asignarClave(nombre);
  }
  
  /**Regresa la cadena del objeto materia.*/
  public String toString() {
    String cad = "";
    cad += this.clave;
    cad += " " + this.semestre;
    cad += " " + this.nombre;
    return cad;
  }
  
  /**Verifica que dos materias sean iguales.*/
  public Boolean equals(Materia materia) {
    Boolean band = this.nombre.equals(materia.nombre) 
            && this.semestre.equals(materia.semestre);
    return band;
  }
  
  /**Asigna la clave a la materia.*/
  public void asignarClave(String nombre) {
    
    switch (nombre) {
      case "Analisis de algoritmos": {
        clave = "1-CT-IS-04";
        break;
      }
      case "Teoria de la computacion": {
        clave = "1-CT-IS-05";
        break;
      }
      case "Construccion y evolucion del software": {
        clave = "1-CT-IS-06";
        break;
      }
      case "Bases de datos": {
        clave = "1-CT-IS-07";
        break;
      }
      case "Analisis de requisitos": {
        clave = "1-CT-IS-08";
        break;
      }
      case "Programacion web": {
        clave = "1-CT-IS-09";
        break;
      }
      case "Sistemas operativos": {
        clave = "1-CT-IS-10";
        break;
      }
      case "Aseguramiento de la calidad del software": {
        clave = "1-CT-IS-11";
        break;
      }
      case "Analisis y modelamiento de software": {
        clave = "1-CT-IS-12";
        break;
      }
      case "Programacion de sistemas": {
        clave = "1-CT-IS-13";
        break;
      }
      case "Arquitectura de computadoras": {
        clave = "1-CT-IS-14";
        break;
      }
      case "Lenguajes de programacion": {
        clave = "1-CT-IS-15";
        break;
      }
      case "Tecnicas de pruebas de software": {
        clave = "1-CT-IS-16";
        break;
      }
      case "Dise�o de software": {
        clave = "1-CT-IS-17";
        break;
      }
      case "Metodologia de la investigacion": {
        clave = "1-CT-IS-18";
        break;
      }
      case "Redes de computadoras": {
        clave = "1-CT-IS-19";
        break;
      }
      case "Normatividad y legislacion": {
        clave = "1-CT-IS-20";
        break;
      }
      case "Arquitectura de software": {
        clave = "1-CT-IS-21";
        break;
      }
      case "Sistemas distribuidos": {
        clave = "1-CT-IS-22";
        break;
      }
      case "Administracion de proyectos I": {
        clave = "1-CT-IS-23";
        break;
      }
      case "Metricas de software": {
        clave = "1-CT-IS-24";
        break;
      }
      case "Dise�o de experimentos en ingenieria de software": {
        clave = "1-CT-IS-25";
        break;
      }
      case "Administracion de proyectos II": {
        clave = "1-CT-IS-26";
        break;
      }
      case "Gestion tecnologica": {
        clave = "1-CT-IS-27";
        break;
      }
      case "Especialidad en bases de datos I": {
        clave = "1-CT-TB-01";
        break;
      }
      case "Especialidad en bases de datos II": {
        clave = "1-CT-TB-02";
        break;
      }
      case "Administracion de bases de datos": {
        clave = "1-CT-TB-03";
        break;
      }
      case "Inteligencia de negocios": {
        clave = "1-CT-TB-04";
        break;
      }
      case "Inteligencia artificial": {
        clave = "1-CT-IA-01";
        break;
      }
      case "Seminario de inteligencia artificial I": {
        clave = "1-CT-IA-02";
        break;
      }
      case "Seminario de inteligencia artificial II": {
        clave = "1-CT-IA-03";
        break;
      }
      case "Computacion movil": {
        clave = "1-CT-IA-04";
        break;
      }
      case "Sistemas embebidos": {
        clave = "1-CT-IA-05";
        break;
      }
      case "Sistemas en tiempo real": {
        clave = "1-CT-IA-06";
        break;
      }
      case "XML 1": {
        clave = "1-CT-AW-01";
        break;
      }
      case "XML 2": {
        clave = "1-CT-AW-02";
        break;
      }
      case "Mapeo objeto/relacional": {
        clave = "1-CT-AW-03";
        break;
      }
      default: {
        break;
      }
    }
    
    
  }
  
  
}
