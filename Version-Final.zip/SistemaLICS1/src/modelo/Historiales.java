package modelo;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Historiales {
	private String semestre;
	private String matricula;
	private String cve_materia;
	private String status;
	ArrayList<Historiales> lista = new ArrayList<>();
	
	public Historiales(String semestre, String matricula, String cve_materia, String status) {
		this.semestre = semestre;
		this.matricula = matricula;
		this.cve_materia = cve_materia;
		this.status = status;
	}

	public Historiales() {
		
	}
	
	public String getSemestre() {
		return semestre;
	}

	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCve_materia() {
		return cve_materia;
	}

	public void setCve_materia(String cve_materia) {
		this.cve_materia = cve_materia;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public ArrayList<Historiales> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Historiales> lista) {
		this.lista = lista;
	}
	
	public boolean checarDimension(ArrayList<Historiales> lista){
		boolean bandera = false;
			if( getLista().size() <= 7 ) {
				bandera = true;
			}
		return bandera;
	}
	
	public void agrearCursando(Historiales historial){
		
		if( checarDimension(lista) ) {
			lista.add(historial);
			setLista(lista);
			System.out.println("Agregado");
			System.out.println("tama�o: "+lista.size());
		}else {
			JOptionPane.showMessageDialog(null, "Solo puedes cursar 7 materias por Semestre");
		}
	}
	
	/*public Historiales respaldarLista(){
		Historiales respaldar;
		respaldar = lista;
		
		return respaldar;
	}*/
}