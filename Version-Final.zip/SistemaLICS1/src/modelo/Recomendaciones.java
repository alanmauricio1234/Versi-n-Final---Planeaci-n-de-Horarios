package modelo;

public class Recomendaciones {
	private String nombre_materia;
	private String alumnos;
	
	public Recomendaciones(String nombre_materia, String alumnos) {
		this.nombre_materia = nombre_materia;
		this.alumnos = alumnos;
	}

	public Recomendaciones() {
		
	}
	
	public String getNombre_materia() {
		return nombre_materia;
	}

	public void setNombre_materia(String nombre_materia) {
		this.nombre_materia = nombre_materia;
	}

	public String getRecomendacion() {
		return alumnos;
	}

	public void setRecomendacion(String recomendacion) {
		this.alumnos = recomendacion;
	}
	
	
}
